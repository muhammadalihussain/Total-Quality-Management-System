USE [master]
GO
/****** Object:  Database [TQMS]    Script Date: 6/7/2026 11:44:07 PM ******/
CREATE DATABASE [TQMS]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'TQMS', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER2016\MSSQL\DATA\TQMS.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'TQMS_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER2016\MSSQL\DATA\TQMS_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO
ALTER DATABASE [TQMS] SET COMPATIBILITY_LEVEL = 130
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [TQMS].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [TQMS] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [TQMS] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [TQMS] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [TQMS] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [TQMS] SET ARITHABORT OFF 
GO
ALTER DATABASE [TQMS] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [TQMS] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [TQMS] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [TQMS] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [TQMS] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [TQMS] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [TQMS] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [TQMS] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [TQMS] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [TQMS] SET  DISABLE_BROKER 
GO
ALTER DATABASE [TQMS] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [TQMS] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [TQMS] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [TQMS] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [TQMS] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [TQMS] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [TQMS] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [TQMS] SET RECOVERY FULL 
GO
ALTER DATABASE [TQMS] SET  MULTI_USER 
GO
ALTER DATABASE [TQMS] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [TQMS] SET DB_CHAINING OFF 
GO
ALTER DATABASE [TQMS] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [TQMS] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [TQMS] SET DELAYED_DURABILITY = DISABLED 
GO
EXEC sys.sp_db_vardecimal_storage_format N'TQMS', N'ON'
GO
ALTER DATABASE [TQMS] SET QUERY_STORE = OFF
GO
USE [TQMS]
GO
ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO
ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO
ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO
ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO
USE [TQMS]
GO
/****** Object:  UserDefinedFunction [dbo].[fun_splitstring]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create FUNCTION [dbo].[fun_splitstring] ( @stringToSplit VARCHAR(8000) )
    RETURNS
        @returnList TABLE ([Param] [nvarchar] (500))
AS
 
BEGIN
 
    DECLARE @name NVARCHAR(255)
    DECLARE @pos INT
 
    WHILE CHARINDEX(',', @stringToSplit) > 0
    BEGIN
        SELECT @pos  = CHARINDEX(',', @stringToSplit) 
        SELECT @name = SUBSTRING(@stringToSplit, 1, @pos-1)
 
        INSERT INTO @returnList
        SELECT @name
 
        SELECT @stringToSplit = SUBSTRING(@stringToSplit, @pos+1, LEN(@stringToSplit)-@pos)
    END
 
    INSERT INTO @returnList
    SELECT @stringToSplit
 
    RETURN
END


--SELECT [Param] FROM dbo.splitstring('a,b,c')
GO
/****** Object:  Table [dbo].[AnalysisCategories]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AnalysisCategories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [varchar](100) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CAPA]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CAPA](
	[CAPAID] [int] IDENTITY(1,1) NOT NULL,
	[CAPA_Code] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[FromDepartmentID] [int] NULL,
	[CreatedBy] [int] NULL,
	[Priority] [nvarchar](20) NULL,
	[StatusId] [nvarchar](50) NULL,
	[TargetDate] [date] NULL,
	[ClosureDate] [date] NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
	[ClosedAt] [datetime] NULL,
	[ItemId] [nvarchar](50) NULL,
	[ItemVarietyID] [nvarchar](50) NULL,
	[SalesId] [nvarchar](50) NULL,
	[Site] [nchar](10) NULL,
	[Customer] [nvarchar](50) NULL,
	[ItemName] [nvarchar](50) NULL,
	[RejectRemarks] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[CAPAID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CAPA_Assignments]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CAPA_Assignments](
	[AssignmentID] [int] IDENTITY(1,1) NOT NULL,
	[CAPAID] [int] NOT NULL,
	[UserID] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[CreatedBy] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CAPAActions]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CAPAActions](
	[ActionID] [int] IDENTITY(1,1) NOT NULL,
	[RootCauseID] [int] NULL,
	[ActionCode] [nvarchar](50) NULL,
	[ActionType] [nvarchar](20) NULL,
	[ActionTitle] [nvarchar](255) NULL,
	[ActionDescription] [nvarchar](max) NULL,
	[AssignedTo] [int] NULL,
	[DueDate] [date] NULL,
	[Status] [nvarchar](50) NULL,
	[Priority] [nvarchar](20) NULL,
	[CreatedBy] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[CompletedAt] [datetime] NULL,
	[CompletionRemarks] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[ActionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CAPAActionsEffectiveness]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CAPAActionsEffectiveness](
	[ActionID] [int] IDENTITY(1,1) NOT NULL,
	[RootCauseID] [int] NOT NULL,
	[DetailsOfRootCause] [nvarchar](max) NOT NULL,
	[CorectiveAction] [nvarchar](max) NULL,
	[PreventiveAction] [nvarchar](max) NULL,
	[CreatedBy] [int] NOT NULL,
	[CAPAID] [int] NOT NULL,
	[ActionTaken] [bit] NULL,
	[IsEffective] [bit] NULL,
	[Remarks] [nvarchar](max) NULL,
	[CreatedAt] [datetime] NULL,
	[VerifiedBy] [int] NULL,
	[VerifiedAt] [datetime] NULL,
	[UpdatedBy] [int] NULL,
 CONSTRAINT [PK_CorrectiveAndPreventiveActions] PRIMARY KEY CLUSTERED 
(
	[ActionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CAPAAssignments]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CAPAAssignments](
	[AssignmentID] [int] IDENTITY(1,1) NOT NULL,
	[CAPAID] [int] NULL,
	[RootCauseID] [int] NULL,
	[ActionID] [int] NULL,
	[AssignedTo] [int] NULL,
	[AssignedBy] [int] NULL,
	[AssignmentDate] [datetime] NULL,
	[ExpectedCompletionDate] [date] NULL,
	[ActualCompletionDate] [date] NULL,
	[ActionTaken] [bit] NULL,
	[ActionTakenRemarks] [nvarchar](max) NULL,
	[IsEffective] [bit] NULL,
	[EffectivenessRemarks] [nvarchar](max) NULL,
	[EffectivenessCheckedBy] [int] NULL,
	[EffectivenessCheckedAt] [datetime] NULL,
	[Status] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[AssignmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Categories]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](150) NULL,
	[IsActve] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Certifications]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Certifications](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductId] [int] NULL,
	[CertificationName] [varchar](100) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[COA]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COA](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[PreparedBy] [int] NOT NULL,
	[CheckedBy] [int] NULL,
	[ApprovedBy] [int] NULL,
	[Status] [int] NULL,
	[PreparedAt] [datetime] NULL,
	[CheckedAt] [datetime] NULL,
	[ApprovedAt] [datetime] NULL,
	[LotNumber] [nvarchar](100) NOT NULL,
	[ProductionDate] [date] NULL,
	[ItemId] [nvarchar](50) NULL,
	[ItemVarietyID] [nvarchar](50) NULL,
	[SalesId] [nvarchar](50) NULL,
	[Site] [nchar](10) NULL,
	[ItemName] [nvarchar](50) NULL,
	[RFNItemNumber] [nvarchar](50) NULL,
	[ACCOUNTNUM] [nvarchar](50) NULL,
	[ExpiryDate] [date] NULL,
	[Customer] [nvarchar](max) NULL,
 CONSTRAINT [PK_COA] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Colors]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Colors](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](100) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CompanyInfo]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CompanyInfo](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NULL,
	[Address1] [nvarchar](max) NULL,
	[Address2] [nvarchar](max) NULL,
	[ContactTell] [nvarchar](20) NULL,
	[ContactCell] [nvarchar](20) NULL,
	[Fax] [nvarchar](20) NULL,
	[Email] [varchar](50) NULL,
	[Code] [nvarchar](20) NULL,
	[IssueNo] [nvarchar](20) NULL,
	[Title] [varchar](50) NULL,
 CONSTRAINT [PK_CompanyInfo] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Departments]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Departments](
	[DepartmentID] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentCode] [nvarchar](20) NOT NULL,
	[DepartmentName] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](255) NULL,
	[IsActive] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
	[Email] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[DepartmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EmailConcernDeparts]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmailConcernDeparts](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DepartmentID] [int] NOT NULL,
	[CAPAID] [int] NULL,
 CONSTRAINT [PK_EmailConcernDeparts] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Forms]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Forms](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](50) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[IssueName]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[IssueName](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[IssueNo] [nvarchar](50) NULL,
 CONSTRAINT [PK_IssueName] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MenuItems]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MenuItems](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Url] [nvarchar](100) NULL,
	[ParentId] [int] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[Icon] [nvarchar](50) NULL,
	[Sort] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Packaging]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Packaging](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductId] [int] NULL,
	[Material] [varchar](100) NULL,
	[NetWeight] [varchar](50) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Permissions]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Permissions](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProductAnalysis]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductAnalysis](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductId] [int] NULL,
	[CategoryId] [int] NULL,
	[ParameterName] [varchar](150) NULL,
	[Unit] [varchar](50) NULL,
	[Limits] [varchar](50) NULL,
	[Status] [varchar](20) NULL,
	[IsActive] [bit] NULL,
	[Method] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductName] [nvarchar](200) NULL,
	[ProductCode] [nvarchar](50) NULL,
	[CategoryID] [int] NULL,
	[FormID] [int] NULL,
	[ColorID] [int] NULL,
	[CountryOfOrigin] [nvarchar](100) NULL,
	[Ingredients] [nvarchar](max) NULL,
	[IngredientsDeclaration] [nvarchar](max) NULL,
	[SuitableFor] [nvarchar](200) NULL,
	[Additives] [nvarchar](200) NULL,
	[Functionalities] [nvarchar](200) NULL,
	[Description] [nvarchar](max) NULL,
	[ShelfLife] [nvarchar](200) NULL,
	[StorageConditions] [nvarchar](max) NULL,
	[Uses] [nvarchar](max) NULL,
	[CreatedAt] [datetime] NULL,
	[IsActive] [bit] NULL,
	[ItemVarietyID] [nvarchar](10) NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[QCTestResults]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[QCTestResults](
	[TestResultID] [int] IDENTITY(1,1) NOT NULL,
	[COAID] [int] NULL,
	[ProductAnalysisID] [int] NULL,
	[Result] [nvarchar](max) NULL,
	[IsPassed] [bit] NULL,
	[VerifiedBy] [int] NULL,
	[VerifiedAt] [datetime] NULL,
	[PreparedBy] [int] NULL,
	[PreparedAt] [datetime] NULL,
	[IsActive] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RoleMenus]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RoleMenus](
	[RoleId] [int] NOT NULL,
	[MenuId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC,
	[MenuId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Roles]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roles](
	[RoleID] [int] IDENTITY(1,1) NOT NULL,
	[RoleCode] [nvarchar](30) NOT NULL,
	[RoleName] [nvarchar](100) NOT NULL,
	[RoleLevel] [int] NULL,
	[Description] [nvarchar](255) NULL,
	[IsActive] [bit] NULL,
	[CreatedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RoleID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RootCauses]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RootCauses](
	[RootCauseID] [int] IDENTITY(1,1) NOT NULL,
	[CAPAID] [int] NULL,
	[RootCauseCode] [nvarchar](50) NULL,
	[RootCauseTitle] [nvarchar](255) NOT NULL,
	[RootCauseDetails] [nvarchar](max) NULL,
	[Category] [nvarchar](100) NULL,
	[CreatedBy] [int] NULL,
	[CreatedAt] [datetime] NULL,
	[IsVerified] [bit] NULL,
	[VerifiedBy] [int] NULL,
	[VerifiedAt] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RootCauseID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RootCauseType]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RootCauseType](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](max) NULL,
 CONSTRAINT [PK_RootCauseType] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Sites]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Sites](
	[SiteID] [int] IDENTITY(1,1) NOT NULL,
	[SiteName] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[SiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Status]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Status](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[StatusName] [nvarchar](50) NULL,
	[IsActive] [bit] NULL,
 CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[UserCode] [nvarchar](50) NOT NULL,
	[FullName] [nvarchar](255) NOT NULL,
	[Email] [nvarchar](255) NULL,
	[PasswordHash] [nvarchar](255) NULL,
	[PhoneNumber] [nvarchar](20) NULL,
	[DepartmentID] [int] NULL,
	[RoleID] [int] NULL,
	[ReportingTo] [int] NULL,
	[IsActive] [bit] NULL,
	[CreatedAt] [datetime] NULL,
	[UpdatedAt] [datetime] NULL,
	[LastLogin] [datetime] NULL,
	[RawPassword] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserSiteAccess]    Script Date: 6/7/2026 11:44:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserSiteAccess](
	[AccessID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[SiteID] [int] NOT NULL,
	[IsActive] [bit] NULL,
	[GrantedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[AccessID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[AnalysisCategories] ON 

INSERT [dbo].[AnalysisCategories] ([Id], [CategoryName], [IsActive]) VALUES (1, N'Chemical Parameters', 1)
INSERT [dbo].[AnalysisCategories] ([Id], [CategoryName], [IsActive]) VALUES (2, N'Heavy Metals', 1)
INSERT [dbo].[AnalysisCategories] ([Id], [CategoryName], [IsActive]) VALUES (3, N'Microbiological Attributes', 1)
INSERT [dbo].[AnalysisCategories] ([Id], [CategoryName], [IsActive]) VALUES (4, N'Allergens', 1)
INSERT [dbo].[AnalysisCategories] ([Id], [CategoryName], [IsActive]) VALUES (5, N'Attributes', 1)
SET IDENTITY_INSERT [dbo].[AnalysisCategories] OFF
GO
SET IDENTITY_INSERT [dbo].[CAPA] ON 

INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (1, N'CAPA-001', N'Motor not working in Line-1, causing production delay', 1, 1, N'HIGH', N'7', CAST(N'1900-01-01' AS Date), CAST(N'1900-01-01' AS Date), CAST(N'2025-04-24T10:30:00.000' AS DateTime), CAST(N'2026-05-06T15:03:00.820' AS DateTime), NULL, NULL, NULL, NULL, NULL, NULL, NULL, N'asdsadsa')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (11, N'CAPA-002', N'test', 1, 1, N'MEDIUM', N'5', CAST(N'2026-05-08' AS Date), CAST(N'2026-05-08' AS Date), CAST(N'2026-04-23T15:28:42.353' AS DateTime), CAST(N'2026-05-08T14:21:32.727' AS DateTime), CAST(N'2026-06-02T18:42:35.457' AS DateTime), N'ITM-000029', N'V0005', N'014465', N'1         ', N'ZAINAB & AISHA ENTERPRISE', N'TIN 25Kg Rice Glucose 45 BE', N'')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (12, N'CAPA-012', N'test', 1, 1, N'MEDIUM', N'7', CAST(N'1900-01-01' AS Date), CAST(N'1900-01-01' AS Date), CAST(N'2026-05-07T15:24:22.180' AS DateTime), CAST(N'2026-05-08T09:06:32.353' AS DateTime), NULL, N'ITM-000909', N'V0031', N'013869', N'1         ', N'ADDITIVE SOLUTIONS PTY LTD', N'SPACEKRAFT IBC TOTES 1364 KG', N'sorry this item has been rejected')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (13, N'CAPA-013', N'test', 1, 1, N'MEDIUM', N'6', CAST(N'2026-05-08' AS Date), CAST(N'2026-05-06' AS Date), CAST(N'2026-05-07T15:34:52.833' AS DateTime), CAST(N'2026-05-08T15:05:57.303' AS DateTime), NULL, N'ITM-000909', N'V0031', N'013869', N'1         ', N'ADDITIVE SOLUTIONS PTY LTD', N'SPACEKRAFT IBC TOTES 1364 KG', N'')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (14, N'CAPA-014', N'test', 1, 1, N'MEDIUM', N'5', CAST(N'2026-05-10' AS Date), CAST(N'2026-05-10' AS Date), CAST(N'2026-05-08T15:54:47.963' AS DateTime), CAST(N'2026-05-10T18:49:19.710' AS DateTime), CAST(N'2026-06-02T16:57:04.967' AS DateTime), N'ITM-000909', N'V0031', N'013869', N'1         ', N'ADDITIVE SOLUTIONS PTY LTD', N'SPACEKRAFT IBC TOTES 1364 KG', N'')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (16, N'CAPA-015', N'test', 1, 1, N'MEDIUM', N'5', CAST(N'2026-06-13' AS Date), CAST(N'2026-06-18' AS Date), CAST(N'2026-05-11T16:05:35.743' AS DateTime), CAST(N'2026-06-01T22:29:07.327' AS DateTime), CAST(N'2026-06-02T16:41:08.610' AS DateTime), N'ITM-000909', N'V0031', N'013869', N'1         ', N'ADDITIVE SOLUTIONS PTY LTD', N'SPACEKRAFT IBC TOTES 1364 KG', N'')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (17, N'C-017', N'testt', 1, 1, N'MEDIUM', N'7', CAST(N'1900-01-01' AS Date), CAST(N'1900-01-01' AS Date), CAST(N'2026-05-12T15:18:21.310' AS DateTime), CAST(N'2026-06-01T22:27:13.813' AS DateTime), NULL, N'ITM-000909', N'V0031', N'013869', N'1         ', N'ADDITIVE SOLUTIONS PTY LTD', N'SPACEKRAFT IBC TOTES 1364 KG', N'sdsdsd')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (18, N'C-018', N'asdsa', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:32:55.273' AS DateTime), CAST(N'2026-06-05T15:32:55.273' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (19, N'C-019', N'asdsa', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:38:37.933' AS DateTime), CAST(N'2026-06-05T15:38:37.933' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (20, N'C-020', N'asdsa', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:39:37.710' AS DateTime), CAST(N'2026-06-05T15:39:37.710' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (21, N'C-021', N'asdsa', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:41:52.837' AS DateTime), CAST(N'2026-06-05T15:41:52.837' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (22, N'C-022', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:51:00.657' AS DateTime), CAST(N'2026-06-05T15:51:00.657' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (23, N'C-023', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:51:09.020' AS DateTime), CAST(N'2026-06-05T15:51:09.020' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (24, N'C-024', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:51:47.870' AS DateTime), CAST(N'2026-06-05T15:51:47.870' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (25, N'C-025', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:53:52.730' AS DateTime), CAST(N'2026-06-05T15:53:52.730' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (26, N'C-026', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:54:08.910' AS DateTime), CAST(N'2026-06-05T15:54:08.910' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (27, N'C-027', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:55:23.850' AS DateTime), CAST(N'2026-06-05T15:55:23.850' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (28, N'C-028', N'asdsad', 1, 1, N'MEDIUM', N'1', NULL, NULL, CAST(N'2026-06-05T15:57:48.047' AS DateTime), CAST(N'2026-06-05T15:57:48.047' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (29, N'C-029', N'test', 1, 1, N'MEDIUM', N'6', CAST(N'2026-06-05' AS Date), CAST(N'2026-06-06' AS Date), CAST(N'2026-06-05T19:10:16.803' AS DateTime), CAST(N'2026-06-05T19:12:43.333' AS DateTime), NULL, N'ITM-000010', N'V0003', N'001233', N'1         ', N'CREST ENTERPRISE', N'Conventional Clarified Rice Syrup 42 DE (43 BE)', N'')
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (30, N'C-030', N'test', 1, 1, N'MEDIUM', N'6', CAST(N'2026-06-05' AS Date), CAST(N'2026-06-05' AS Date), CAST(N'2026-06-05T19:11:18.370' AS DateTime), CAST(N'2026-06-05T19:23:55.830' AS DateTime), NULL, N'ITM-000010', N'V0003', N'001233', N'1         ', N'CREST ENTERPRISE', N'Conventional Clarified Rice Syrup 42 DE (43 BE)', NULL)
INSERT [dbo].[CAPA] ([CAPAID], [CAPA_Code], [Description], [FromDepartmentID], [CreatedBy], [Priority], [StatusId], [TargetDate], [ClosureDate], [CreatedAt], [UpdatedAt], [ClosedAt], [ItemId], [ItemVarietyID], [SalesId], [Site], [Customer], [ItemName], [RejectRemarks]) VALUES (31, N'C-031', N'dsfds', 1, 1, N'MEDIUM', N'6', CAST(N'2026-06-05' AS Date), CAST(N'2026-06-05' AS Date), CAST(N'2026-06-05T20:23:37.007' AS DateTime), CAST(N'2026-06-05T20:45:12.107' AS DateTime), NULL, N'ITM-000029', N'V0005', N'001234', N'1         ', N'BRIGHT TRADER', N'TIN 25Kg Rice Glucose 45 BE', NULL)
SET IDENTITY_INSERT [dbo].[CAPA] OFF
GO
SET IDENTITY_INSERT [dbo].[CAPA_Assignments] ON 

INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (6, 1, 16, 1, CAST(N'2026-05-08T11:34:39.660' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (7, 1, 25, 1, CAST(N'2026-05-08T11:35:21.737' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (8, 1, 24, 1, CAST(N'2026-05-08T11:35:21.737' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (9, 1, 17, 1, CAST(N'2026-05-08T11:35:21.737' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (10, 1, 20, 1, CAST(N'2026-05-08T11:35:46.407' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (23, 13, 17, 1, CAST(N'2026-05-08T15:05:06.973' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (24, 13, 16, 1, CAST(N'2026-05-08T15:05:06.973' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (27, 14, 24, 1, CAST(N'2026-05-10T19:09:20.287' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (28, 14, 17, 1, CAST(N'2026-05-10T19:09:20.287' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (33, 14, 1, 1, CAST(N'2026-06-02T16:55:11.530' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (1033, 11, 1, 1, CAST(N'2026-06-02T18:11:42.103' AS DateTime), 1)
INSERT [dbo].[CAPA_Assignments] ([AssignmentID], [CAPAID], [UserID], [IsActive], [CreatedAt], [CreatedBy]) VALUES (1034, 31, 1, 1, CAST(N'2026-06-05T20:45:43.430' AS DateTime), 1)
SET IDENTITY_INSERT [dbo].[CAPA_Assignments] OFF
GO
SET IDENTITY_INSERT [dbo].[CAPAActions] ON 

INSERT [dbo].[CAPAActions] ([ActionID], [RootCauseID], [ActionCode], [ActionType], [ActionTitle], [ActionDescription], [AssignedTo], [DueDate], [Status], [Priority], [CreatedBy], [CreatedAt], [CompletedAt], [CompletionRemarks]) VALUES (3, 1, N'A-001', N'CORRECTIVE', N'Install Voltage Stabilizer', N'Install automatic voltage stabilizer to regulate power supply', 3, CAST(N'2025-05-01' AS Date), N'PENDING', N'MEDIUM', 1, CAST(N'2026-04-03T12:07:34.840' AS DateTime), NULL, NULL)
INSERT [dbo].[CAPAActions] ([ActionID], [RootCauseID], [ActionCode], [ActionType], [ActionTitle], [ActionDescription], [AssignedTo], [DueDate], [Status], [Priority], [CreatedBy], [CreatedAt], [CompletedAt], [CompletionRemarks]) VALUES (4, 1, N'A-002', N'PREVENTIVE', N'Add Voltage Monitoring System', N'Install real-time voltage monitoring system with alerts', 3, CAST(N'2025-05-15' AS Date), N'PENDING', N'MEDIUM', 1, CAST(N'2026-04-03T12:07:34.840' AS DateTime), NULL, NULL)
INSERT [dbo].[CAPAActions] ([ActionID], [RootCauseID], [ActionCode], [ActionType], [ActionTitle], [ActionDescription], [AssignedTo], [DueDate], [Status], [Priority], [CreatedBy], [CreatedAt], [CompletedAt], [CompletionRemarks]) VALUES (5, 2, N'A-003', N'CORRECTIVE', N'Retrain Operator', N'Provide comprehensive training on SOP to operator', 4, CAST(N'2025-05-05' AS Date), N'PENDING', N'MEDIUM', 1, CAST(N'2026-04-03T12:07:34.840' AS DateTime), NULL, NULL)
INSERT [dbo].[CAPAActions] ([ActionID], [RootCauseID], [ActionCode], [ActionType], [ActionTitle], [ActionDescription], [AssignedTo], [DueDate], [Status], [Priority], [CreatedBy], [CreatedAt], [CompletedAt], [CompletionRemarks]) VALUES (6, 2, N'A-004', N'PREVENTIVE', N'Implement SOP Checklist', N'Create and implement mandatory SOP checklist before operation', 4, CAST(N'2025-05-20' AS Date), N'PENDING', N'MEDIUM', 1, CAST(N'2026-04-03T12:07:34.840' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[CAPAActions] OFF
GO
SET IDENTITY_INSERT [dbo].[CAPAActionsEffectiveness] ON 

INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (2, 8, N'fff', N'ffff', N'ff', 1, 17, 0, 0, NULL, CAST(N'2026-05-15T14:06:41.457' AS DateTime), NULL, NULL, 1)
INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (3, 2, N'sdsdsd', N'sdsds', N'sdsd', 1, 17, 0, 0, NULL, CAST(N'2026-05-16T23:57:20.940' AS DateTime), NULL, NULL, NULL)
INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (4, 2, N'test', N'test', N'testsssssssss', 1, 16, 1, 1, N'ok', CAST(N'2026-06-01T22:37:08.180' AS DateTime), 1, CAST(N'2026-06-02T16:41:08.603' AS DateTime), 1)
INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (5, 2, N'wwwww', N'www', N'ww', 1, 16, 1, 1, N'ok', CAST(N'2026-06-02T08:40:22.447' AS DateTime), 1, CAST(N'2026-06-02T16:41:08.603' AS DateTime), NULL)
INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (6, 2, N'asdsadsa', N'sadsa', N'asdsa', 1, 14, 1, 1, N'sadsadsa', CAST(N'2026-06-02T16:55:25.357' AS DateTime), 1, CAST(N'2026-06-02T16:57:04.960' AS DateTime), NULL)
INSERT [dbo].[CAPAActionsEffectiveness] ([ActionID], [RootCauseID], [DetailsOfRootCause], [CorectiveAction], [PreventiveAction], [CreatedBy], [CAPAID], [ActionTaken], [IsEffective], [Remarks], [CreatedAt], [VerifiedBy], [VerifiedAt], [UpdatedBy]) VALUES (1006, 1, N'asdsadsad', N'asdas', N'asdsad', 1, 11, 1, 1, N'sssss', CAST(N'2026-06-02T18:11:59.520' AS DateTime), 1, CAST(N'2026-06-02T18:42:35.453' AS DateTime), NULL)
SET IDENTITY_INSERT [dbo].[CAPAActionsEffectiveness] OFF
GO
SET IDENTITY_INSERT [dbo].[CAPAAssignments] ON 

INSERT [dbo].[CAPAAssignments] ([AssignmentID], [CAPAID], [RootCauseID], [ActionID], [AssignedTo], [AssignedBy], [AssignmentDate], [ExpectedCompletionDate], [ActualCompletionDate], [ActionTaken], [ActionTakenRemarks], [IsEffective], [EffectivenessRemarks], [EffectivenessCheckedBy], [EffectivenessCheckedAt], [Status]) VALUES (4, 1, 1, 1, 3, 2, CAST(N'2026-04-03T12:09:49.907' AS DateTime), CAST(N'2025-05-01' AS Date), NULL, 0, NULL, 0, NULL, NULL, NULL, N'ASSIGNED')
INSERT [dbo].[CAPAAssignments] ([AssignmentID], [CAPAID], [RootCauseID], [ActionID], [AssignedTo], [AssignedBy], [AssignmentDate], [ExpectedCompletionDate], [ActualCompletionDate], [ActionTaken], [ActionTakenRemarks], [IsEffective], [EffectivenessRemarks], [EffectivenessCheckedBy], [EffectivenessCheckedAt], [Status]) VALUES (5, 1, 1, 2, 3, 2, CAST(N'2026-04-03T12:09:49.907' AS DateTime), CAST(N'2025-05-15' AS Date), NULL, 0, NULL, 0, NULL, NULL, NULL, N'ASSIGNED')
INSERT [dbo].[CAPAAssignments] ([AssignmentID], [CAPAID], [RootCauseID], [ActionID], [AssignedTo], [AssignedBy], [AssignmentDate], [ExpectedCompletionDate], [ActualCompletionDate], [ActionTaken], [ActionTakenRemarks], [IsEffective], [EffectivenessRemarks], [EffectivenessCheckedBy], [EffectivenessCheckedAt], [Status]) VALUES (6, 1, 2, 3, 4, 2, CAST(N'2026-04-03T12:09:49.907' AS DateTime), CAST(N'2025-05-05' AS Date), NULL, 0, NULL, 0, NULL, NULL, NULL, N'ASSIGNED')
INSERT [dbo].[CAPAAssignments] ([AssignmentID], [CAPAID], [RootCauseID], [ActionID], [AssignedTo], [AssignedBy], [AssignmentDate], [ExpectedCompletionDate], [ActualCompletionDate], [ActionTaken], [ActionTakenRemarks], [IsEffective], [EffectivenessRemarks], [EffectivenessCheckedBy], [EffectivenessCheckedAt], [Status]) VALUES (7, 1, 2, 4, 4, 2, CAST(N'2026-04-03T12:09:49.907' AS DateTime), CAST(N'2025-05-20' AS Date), NULL, 0, NULL, 0, NULL, NULL, NULL, N'ASSIGNED')
SET IDENTITY_INSERT [dbo].[CAPAAssignments] OFF
GO
SET IDENTITY_INSERT [dbo].[Categories] ON 

INSERT [dbo].[Categories] ([Id], [Name], [IsActve]) VALUES (1, N'Reduced Sugar Rice Syrup', 1)
INSERT [dbo].[Categories] ([Id], [Name], [IsActve]) VALUES (2, N'Organic Tapioca Syrup', 1)
SET IDENTITY_INSERT [dbo].[Categories] OFF
GO
SET IDENTITY_INSERT [dbo].[Certifications] ON 

INSERT [dbo].[Certifications] ([Id], [ProductId], [CertificationName], [IsActive]) VALUES (6, 1, N'ISO 9001:2015', 1)
INSERT [dbo].[Certifications] ([Id], [ProductId], [CertificationName], [IsActive]) VALUES (7, 1, N'EU & NOP Organic', 1)
INSERT [dbo].[Certifications] ([Id], [ProductId], [CertificationName], [IsActive]) VALUES (8, 1, N'BRC & HACCP', 1)
INSERT [dbo].[Certifications] ([Id], [ProductId], [CertificationName], [IsActive]) VALUES (9, 1, N'HALAL & KOSHER', 1)
SET IDENTITY_INSERT [dbo].[Certifications] OFF
GO
SET IDENTITY_INSERT [dbo].[COA] ON 

INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (41, 1, 1, 1, 10, CAST(N'2026-05-21T16:28:27.403' AS DateTime), CAST(N'2026-05-30T20:56:27.417' AS DateTime), CAST(N'2026-05-30T20:56:36.740' AS DateTime), N'test11ssasas', CAST(N'2026-06-01' AS Date), N'ITM-006622', N'V0040', N'013595', N'1         ', N'FOOD GRADE IBC SCHUTZ 1400KG', N'test11ssasas', N'CUST-003404', CAST(N'2026-07-04' AS Date), NULL)
INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (42, 1, NULL, NULL, 8, CAST(N'2026-06-07T18:34:20.580' AS DateTime), NULL, NULL, N'1111', CAST(N'2026-06-07' AS Date), N'ITM-000029', N'V0005', N'000123', N'1         ', N'TIN 25Kg Rice Glucose 45 BE', N'1111', N'CUST-001534', CAST(N'2026-06-07' AS Date), N'2026-06-07T13:40:00.000Z')
INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (43, 1, NULL, NULL, 8, CAST(N'2026-06-07T18:37:26.747' AS DateTime), NULL, NULL, N'aaa', CAST(N'2026-06-07' AS Date), N'ITM-000029', N'V0005', N'000123', N'1         ', N'TIN 25Kg Rice Glucose 45 BE', N'aaa', N'CUST-001534', CAST(N'2026-06-07' AS Date), N'2026-06-07T13:43:00.000Z')
INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (44, 1, NULL, NULL, 8, CAST(N'2026-06-07T18:42:02.970' AS DateTime), NULL, NULL, N'zzz', CAST(N'2026-06-07' AS Date), N'ITM-000029', N'V0005', N'000123', N'1         ', N'TIN 25Kg Rice Glucose 45 BE', N'zzz', N'CUST-001534', CAST(N'2026-06-07' AS Date), N'2026-06-07T07:41:00.000Z')
INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (45, 1, NULL, NULL, 8, CAST(N'2026-06-07T18:44:51.113' AS DateTime), NULL, NULL, N'aa', CAST(N'2026-06-07' AS Date), N'ITM-000029', N'V0005', N'000123', N'1         ', N'TIN 25Kg Rice Glucose 45 BE', N'aa', N'CUST-001534', CAST(N'2026-06-07' AS Date), N'2026-06-07T13:50:00.000Z')
INSERT [dbo].[COA] ([Id], [PreparedBy], [CheckedBy], [ApprovedBy], [Status], [PreparedAt], [CheckedAt], [ApprovedAt], [LotNumber], [ProductionDate], [ItemId], [ItemVarietyID], [SalesId], [Site], [ItemName], [RFNItemNumber], [ACCOUNTNUM], [ExpiryDate], [Customer]) VALUES (46, 1, NULL, NULL, 8, CAST(N'2026-06-07T18:47:43.930' AS DateTime), NULL, NULL, N'ss', CAST(N'2026-06-07' AS Date), N'ITM-000029', N'V0005', N'000123', N'1         ', N'TIN 25Kg Rice Glucose 45 BE', N'sss', N'CUST-001534', CAST(N'2026-06-07' AS Date), N'FARHAN AGENCIES')
SET IDENTITY_INSERT [dbo].[COA] OFF
GO
SET IDENTITY_INSERT [dbo].[Colors] ON 

INSERT [dbo].[Colors] ([Id], [Name], [IsActive]) VALUES (1, N'Water White', 1)
INSERT [dbo].[Colors] ([Id], [Name], [IsActive]) VALUES (2, N'White', 1)
INSERT [dbo].[Colors] ([Id], [Name], [IsActive]) VALUES (3, N'White to Creamy', 1)
SET IDENTITY_INSERT [dbo].[Colors] OFF
GO
SET IDENTITY_INSERT [dbo].[CompanyInfo] ON 

INSERT [dbo].[CompanyInfo] ([Id], [Name], [Address1], [Address2], [ContactTell], [ContactCell], [Fax], [Email], [Code], [IssueNo], [Title]) VALUES (4, N'MATCO FOODS LIMITED', N'B-1/A, S.I.T.E., Phase 1, Super Highway', N'Industrial Area, Karachi - 75340.', N'+92 21 36411661-3', N'+92 300 8610651', N'+92 21 36881443', N'contact@matcafoods.com', N'QC/4/06', N'Issue 4', N'CERTIFICATE OF ANALYSIS')
SET IDENTITY_INSERT [dbo].[CompanyInfo] OFF
GO
SET IDENTITY_INSERT [dbo].[Departments] ON 

INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (1, N'Admin', N'Admin', N'Full Access Rights', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (2, N'PROD', N'Production', N'Manufacturing and Production Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'hussain.ali.ned@gmail.com')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (3, N'QA', N'Quality Assurance', N'Quality Control and Assurance Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (4, N'MAINT', N'Maintenance', N'Equipment Maintenance Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (5, N'HR', N'HR', N'Human Resources Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (6, N'SAFETY', N'Safety', N'Health and Safety Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
INSERT [dbo].[Departments] ([DepartmentID], [DepartmentCode], [DepartmentName], [Description], [IsActive], [CreatedAt], [UpdatedAt], [Email]) VALUES (7, N'MGMT', N'Management', N'Senior Management Department', 1, CAST(N'2026-04-03T11:17:40.063' AS DateTime), CAST(N'2026-04-03T11:17:40.063' AS DateTime), N'muhammad.ali@matcofoods.com.pk')
SET IDENTITY_INSERT [dbo].[Departments] OFF
GO
SET IDENTITY_INSERT [dbo].[EmailConcernDeparts] ON 

INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (1, 1, 8)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (2, 2, 8)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (3, 3, 8)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (4, 1, 9)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (5, 4, 9)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (6, 2, 9)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (7, 3, 9)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (8, 1, 10)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (12, 5, 12)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (13, 4, 12)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (14, 6, 12)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (23, 1, 11)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (24, 2, 11)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (25, 3, 11)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (27, 7, 13)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (28, 3, 12)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (29, 1, 13)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (30, 1, 14)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (31, 2, 15)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (32, 2, 16)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (33, 1, 17)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (34, 1, 18)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (35, 1, 19)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (36, 1, 20)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (37, 1, 21)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (38, 1, 22)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (39, 1, 23)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (40, 1, 24)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (41, 1, 25)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (42, 1, 26)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (43, 1, 27)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (44, 1, 28)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (45, 2, 29)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (46, 2, 30)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (47, 1, 30)
INSERT [dbo].[EmailConcernDeparts] ([Id], [DepartmentID], [CAPAID]) VALUES (48, 1, 31)
SET IDENTITY_INSERT [dbo].[EmailConcernDeparts] OFF
GO
SET IDENTITY_INSERT [dbo].[Forms] ON 

INSERT [dbo].[Forms] ([Id], [Name], [IsActive]) VALUES (1, N'Liquid', 1)
INSERT [dbo].[Forms] ([Id], [Name], [IsActive]) VALUES (2, N'Dehydrated', 1)
SET IDENTITY_INSERT [dbo].[Forms] OFF
GO
SET IDENTITY_INSERT [dbo].[IssueName] ON 

INSERT [dbo].[IssueName] ([Id], [Name], [IssueNo]) VALUES (1, N'MR/4/08', N'Issue 1')
SET IDENTITY_INSERT [dbo].[IssueName] OFF
GO
SET IDENTITY_INSERT [dbo].[MenuItems] ON 

INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (1, N'Dashboard', N'/dashboard', NULL, 1, CAST(N'2026-03-04T12:43:35.520' AS DateTime), N'GridIcon', 1)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (2, N'User Management', N'#', NULL, 1, CAST(N'2026-03-04T12:43:35.520' AS DateTime), N'UserCircleIcon', 10)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (3, N'Profile', N'/profile', NULL, 0, CAST(N'2026-03-04T12:43:35.520' AS DateTime), N'UserCircleIcon', 0)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (4, N'Users', N'/users', 2, 1, CAST(N'2026-03-21T20:01:13.330' AS DateTime), N'Users', 3)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (5, N'Products', N'/products', NULL, 1, CAST(N'2026-03-23T14:26:49.613' AS DateTime), N'FolderIcon', 4)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (6, N'Products  Specification ', N'#', 0, 0, CAST(N'2026-03-23T14:38:29.397' AS DateTime), N'FolderIcon', 5)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (7, N'Complaints', N'/capa', 0, 1, CAST(N'2026-03-23T14:41:40.813' AS DateTime), N'FolderIcon', 2)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (8, N'Root Cause', N'/rootcause', 9, 1, CAST(N'2026-05-12T12:08:15.953' AS DateTime), N'GroupIcon', 7)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (9, N'Corrective & Preventive ', N'#', 0, 1, CAST(N'2026-05-12T12:16:55.213' AS DateTime), N'Forms', 8)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (10, N'QA', N'/qa', 11, 1, CAST(N'2026-05-17T21:30:26.190' AS DateTime), N'FolderIcon', 9)
INSERT [dbo].[MenuItems] ([Id], [Title], [Url], [ParentId], [IsActive], [CreatedDate], [Icon], [Sort]) VALUES (11, N'Certification Of Analysis', N'#', 0, 1, CAST(N'2026-05-19T15:23:51.970' AS DateTime), N'FolderIcon', 6)
SET IDENTITY_INSERT [dbo].[MenuItems] OFF
GO
SET IDENTITY_INSERT [dbo].[Packaging] ON 

INSERT [dbo].[Packaging] ([Id], [ProductId], [Material], [NetWeight], [IsActive]) VALUES (5, 1, N'Jerry Cans', N'25-30', 1)
INSERT [dbo].[Packaging] ([Id], [ProductId], [Material], [NetWeight], [IsActive]) VALUES (6, 1, N'Drums', N'300', 1)
INSERT [dbo].[Packaging] ([Id], [ProductId], [Material], [NetWeight], [IsActive]) VALUES (7, 1, N'Totes', N'1364', 1)
INSERT [dbo].[Packaging] ([Id], [ProductId], [Material], [NetWeight], [IsActive]) VALUES (8, 1, N'Schutz', N'1400', 1)
SET IDENTITY_INSERT [dbo].[Packaging] OFF
GO
SET IDENTITY_INSERT [dbo].[Permissions] ON 

INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (1, N'CREATE')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (2, N'EDIT')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (3, N'DELETE')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (4, N'VIEW')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (5, N'PREPARE')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (6, N'CHECK')
INSERT [dbo].[Permissions] ([Id], [Code]) VALUES (7, N'APPROVE')
SET IDENTITY_INSERT [dbo].[Permissions] OFF
GO
SET IDENTITY_INSERT [dbo].[ProductAnalysis] ON 

INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (59, 1, 5, N'Moisture', N'', N'19-21', N'', 1, N'Refractometer')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (60, 1, 5, N'pH (50% solution)', N'%', N'4.5-6.5', N'', 1, N'AOAC 945.27')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (61, 1, 5, N'Brix%', N'%', N'79.5-81.5', N'', 1, N'AOAC 932.14')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (62, 1, 5, N'Dextrose Equivalent (DE %)', N'%', N'26-32', N'', 1, N'AOAC 923.0')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (63, 1, 5, N'Glucose (as % of solids)', N'%', N'3.5-8.5', N'', 1, N'HPLC')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (64, 1, 5, N'Maltose (as % of solids)', N'%', N'8.5-20', N'', 1, N'HPLC')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (65, 1, 5, N'Other Carbohydrates', N'%', N'70-86', N'', 1, N'HPLC')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (66, 1, 5, N'Color', N'', N'Extra Light I Amber', N'', 1, N'Visual')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (67, 1, 5, N'Flavor', N'', N'Sweet', N'', 1, N'Organoleptic')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (68, 1, 5, N'Ash%', N'%', N'<0.20', N'', 1, N'')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (69, 1, 3, N'Total Plate Count (cfu/g)', N'cfu/g', N'<500', N'', 1, N'BAM-FDA online Chapter 3')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (70, 1, 3, N'Osmophilic Mold (cfu/g)', N'cfu/g', N'<100', N'', 1, N'BAM-FDA online Chapter 18')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (71, 1, 3, N'Osmophilic Yeast (cfu/g)', N'cfu/g', N'<100', N'', 1, N'BAM-FDA online Chapter 18')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (72, 1, 3, N'B-Coli (cfu/g)', N'cfu/g', N'<10', N'', 1, N'BAM-FDA online Chapter 04')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (73, 1, 3, N'Coliforms (cfu/g)', N'cfu/g', N'<10', N'', 1, N'BAM-FDA online Chapter 04')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (74, 1, 3, N'Salmonella (per 25 g)', N'per 25 g', N'Nil', N'', 1, N'BAM-FDA online Chapter 5')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (75, 1, 2, N'Lead (ppb)', N'ppb', N'<50', N'', 1, N'Based on Journal of Food & Drug Analysis Vol. 12 No.2 2004/ American Eurasian J. Agri & Env. Sci, 6 91): 16- 19/2009 (LOD=20 ppb')
INSERT [dbo].[ProductAnalysis] ([Id], [ProductId], [CategoryId], [ParameterName], [Unit], [Limits], [Status], [IsActive], [Method]) VALUES (76, 1, 2, N'Arsenic (ppb)', N'ppb', N'<100', N'', 1, N'Based on Journal of Food & Drug Analysis Vol. 12 No.2 2004/ American Eurasian J. Agri & Env. Sci, 6 91): 16- 19/2009 (LOD=20 ppb')
SET IDENTITY_INSERT [dbo].[ProductAnalysis] OFF
GO
SET IDENTITY_INSERT [dbo].[Products] ON 

INSERT [dbo].[Products] ([Id], [ProductName], [ProductCode], [CategoryID], [FormID], [ColorID], [CountryOfOrigin], [Ingredients], [IngredientsDeclaration], [SuitableFor], [Additives], [Functionalities], [Description], [ShelfLife], [StorageConditions], [Uses], [CreatedAt], [IsActive], [ItemVarietyID]) VALUES (1, N'ORGANIC BROWN RICE SYRUP 28DE', N'MFOBRS28', 2, 1, 1, N'Pakistan', N'GMO Free Tapioca Starch', N'Clarified Tapioca Syrup ', N'Halal, Kosher, Vegetarian diets', N'No Additives', N'Sweeteners', N'This product has a clean sweet flavor with light buttery
and honey flavor notes. This multifunctional natural
sweetener is produced through enzymatic liquefaction of
Allergen and GMO free tapioca starch using state-of-the
 art technology and environment during processing, filtration
and evaporation to produce concentrated syrup.
', N'18 Months', N'Tapioca Syrup should be stored in cool and dry location
(i.e Temperature <90 F) and away from sunlight.', N'Drink, ice cream, desserts, yoghurt, biscuit, pharmacy,breakfast foods, sauces, baby foods, bakery, snacks,
sucrose, honey substitute for consumer, confectionery cosmetic and other fruit based preparations.
', CAST(N'2026-03-26T10:34:54.897' AS DateTime), 1, N'V0040')
SET IDENTITY_INSERT [dbo].[Products] OFF
GO
SET IDENTITY_INSERT [dbo].[QCTestResults] ON 

INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (40, 41, 59, N'asdsadsa', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (41, 41, 60, N'sdfds', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (42, 41, 61, N'sdfdsf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (43, 41, 62, N'sdfdsf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (44, 41, 63, N'sdfdsf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (45, 41, 64, N'sdfds', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (46, 41, 65, N'sdfs', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (47, 41, 66, N'sdfsdf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (48, 41, 67, N'sdf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (49, 41, 68, N'sdf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (50, 41, 69, N'sdfsd', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (51, 41, 70, N'sdfsdf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (52, 41, 71, N'sdfsd', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (53, 41, 72, N'sdfsd', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (54, 41, 73, N'sdf', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (55, 41, 74, N'sdfds', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (56, 41, 75, N'sdfsd', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
INSERT [dbo].[QCTestResults] ([TestResultID], [COAID], [ProductAnalysisID], [Result], [IsPassed], [VerifiedBy], [VerifiedAt], [PreparedBy], [PreparedAt], [IsActive]) VALUES (57, 41, 76, N'sdfsd', 1, 1, CAST(N'2026-05-30T20:56:27.410' AS DateTime), 1, CAST(N'2026-05-27T20:36:39.513' AS DateTime), 1)
SET IDENTITY_INSERT [dbo].[QCTestResults] OFF
GO
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 1)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 2)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 3)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 4)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 5)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 6)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 7)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 8)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 9)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 10)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (1, 11)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (2, 1)
INSERT [dbo].[RoleMenus] ([RoleId], [MenuId]) VALUES (2, 3)
GO
SET IDENTITY_INSERT [dbo].[Roles] ON 

INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (1, N'ADMIN', N'Head System Administrator', 10, N'Full system access', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (2, N'HOP', N'Head of Production', 8, N'Head of Production', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (3, N'QA_MGR', N'QA Manager', 7, N'Quality Assurance Manager', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (4, N'QA_ENG', N'QA Engineer', 5, N'Quality Assurance Engineer', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (5, N'PROD_MGR', N'Production Manager', 7, N'Production Manager', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (6, N'PROD_SUP', N'Production Supervisor', 5, N'Production Supervisor', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (7, N'PROD_OP', N'Production Operator', 3, N'Production Operator', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (8, N'HOM', N'Head of  Maintenance Engineer', 5, N'Head of Maintenance Engineer', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (9, N'TECHNICIAN', N'Technician', 3, N'Technician', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (10, N'HOHR', N'Head of HR ', 7, N'Human Resources Manager', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (11, N'HOS', N'Head of Safety Officer', 5, N'Head of Safety Officer', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (12, N'HEAD_QA', N'Head of QA', 9, N'Head of Quality Assurance', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
INSERT [dbo].[Roles] ([RoleID], [RoleCode], [RoleName], [RoleLevel], [Description], [IsActive], [CreatedAt]) VALUES (13, N'MANAGER', N'Head of Manager', 8, N'Head of  Manager', 1, CAST(N'2026-04-03T11:31:24.870' AS DateTime))
SET IDENTITY_INSERT [dbo].[Roles] OFF
GO
SET IDENTITY_INSERT [dbo].[RootCauses] ON 

INSERT [dbo].[RootCauses] ([RootCauseID], [CAPAID], [RootCauseCode], [RootCauseTitle], [RootCauseDetails], [Category], [CreatedBy], [CreatedAt], [IsVerified], [VerifiedBy], [VerifiedAt]) VALUES (1, 1, N'RC-001', N'Power Fluctuation', N'Voltage unstable ranging from 180-260V, causing motor trips', N'Equipment', 1, CAST(N'2026-04-03T11:53:16.150' AS DateTime), 0, NULL, NULL)
INSERT [dbo].[RootCauses] ([RootCauseID], [CAPAID], [RootCauseCode], [RootCauseTitle], [RootCauseDetails], [Category], [CreatedBy], [CreatedAt], [IsVerified], [VerifiedBy], [VerifiedAt]) VALUES (2, 1, N'RC-002', N'Operator Error', N'Operator did not follow standard operating procedure', N'Human Error', 1, CAST(N'2026-04-03T11:53:16.150' AS DateTime), 0, NULL, NULL)
SET IDENTITY_INSERT [dbo].[RootCauses] OFF
GO
SET IDENTITY_INSERT [dbo].[RootCauseType] ON 

INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (1, N'Training ')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (2, N'Maintenance')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (3, N'Handling')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (4, N'Inspection')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (5, N'Customer')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (6, N'Resources')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (7, N'Negligence')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (8, N'Storage')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (9, N'Planning')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (10, N'Supplier')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (11, N'Housekeping')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (12, N'Record Keeping')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (13, N'Delivery')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (14, N'Packing')
INSERT [dbo].[RootCauseType] ([ID], [Name]) VALUES (15, N'Other')
SET IDENTITY_INSERT [dbo].[RootCauseType] OFF
GO
SET IDENTITY_INSERT [dbo].[Sites] ON 

INSERT [dbo].[Sites] ([SiteID], [SiteName], [Description], [IsActive], [CreatedDate]) VALUES (1, N'RGD', N'Rice Glucose Division (RGD)', 1, CAST(N'2026-03-04T12:41:47.087' AS DateTime))
INSERT [dbo].[Sites] ([SiteID], [SiteName], [Description], [IsActive], [CreatedDate]) VALUES (2, N'MRP', N'Matco Foods Ltd.', 0, CAST(N'2026-03-04T12:41:47.087' AS DateTime))
INSERT [dbo].[Sites] ([SiteID], [SiteName], [Description], [IsActive], [CreatedDate]) VALUES (3, N'MCS', N'Matco Corn Starch', 0, CAST(N'2026-03-04T12:41:47.087' AS DateTime))
INSERT [dbo].[Sites] ([SiteID], [SiteName], [Description], [IsActive], [CreatedDate]) VALUES (4, N'FFD', N'Falak Foods Limited', 0, CAST(N'2026-03-04T12:41:47.087' AS DateTime))
INSERT [dbo].[Sites] ([SiteID], [SiteName], [Description], [IsActive], [CreatedDate]) VALUES (5, N'BPD', N'Barentz Pakistan Private Limited', 0, CAST(N'2026-03-04T12:41:47.087' AS DateTime))
SET IDENTITY_INSERT [dbo].[Sites] OFF
GO
SET IDENTITY_INSERT [dbo].[Status] ON 

INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (1, N'OPEN', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (2, N'IN PROGRESS', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (3, N'FAIL', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (4, N'PASS', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (5, N'CLOSED', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (6, N'ACCEPTED', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (7, N'REJECTED', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (8, N'CREATED', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (9, N'CHECKED', 1)
INSERT [dbo].[Status] ([Id], [StatusName], [IsActive]) VALUES (10, N'APPROVED', 1)
SET IDENTITY_INSERT [dbo].[Status] OFF
GO
SET IDENTITY_INSERT [dbo].[Users] ON 

INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (1, N'01303', N'Muhammad Ali Hussain', N'muhammad.ali@matcofoods.com.pk', N'$2b$10$5tVrlI7COxNl7BYeoFEZY.j4SyQDC2VKDqHpMbDtJ.geoK.Go/bPW', NULL, 1, 1, NULL, 1, CAST(N'2026-04-03T11:47:49.017' AS DateTime), CAST(N'2026-04-03T11:47:49.017' AS DateTime), NULL, N'12345')
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (16, N'EMP001', N'Ali', N'test1@company.com', NULL, NULL, 1, 7, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (17, N'EMP002', N'Akber', N'test2@company.com', NULL, NULL, 1, 2, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (18, N'EMP003', N'Kamran', N'test3@company.com', NULL, NULL, 1, 8, 2, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (19, N'EMP004', N'Imran', N'test4@company.com', NULL, NULL, 4, 10, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (20, N'EMP005', N'Dawood', N'test5@company.com', NULL, NULL, 2, 6, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (21, N'EMP006', N'Ibrahim', N'test6@company.com', NULL, NULL, 6, 11, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (22, N'EMP007', N'Muzamil', N'test7@company.com', N'$2b$10$h1M4pcxScLH1sblO1wXHBOEa023/.c3UakUSWIs3yx4ZbUeZKTUsC', NULL, 3, 12, NULL, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
INSERT [dbo].[Users] ([UserID], [UserCode], [FullName], [Email], [PasswordHash], [PhoneNumber], [DepartmentID], [RoleID], [ReportingTo], [IsActive], [CreatedAt], [UpdatedAt], [LastLogin], [RawPassword]) VALUES (23, N'EMP008', N'Umer', N'test8@company.com', NULL, NULL, 3, 9, 2, 1, CAST(N'2026-04-03T12:04:10.983' AS DateTime), CAST(N'2026-04-03T12:04:10.983' AS DateTime), NULL, NULL)
SET IDENTITY_INSERT [dbo].[Users] OFF
GO
SET IDENTITY_INSERT [dbo].[UserSiteAccess] ON 

INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (7, 16, 1, 1, CAST(N'2026-03-05T11:06:11.313' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (8, 17, 1, 1, CAST(N'2026-03-05T11:06:11.313' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (9, 18, 1, 1, CAST(N'2026-03-05T11:06:11.313' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (10, 19, 1, 1, CAST(N'2026-03-05T11:06:11.313' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (11, 20, 1, 1, CAST(N'2026-03-05T14:21:49.267' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (12, 21, 1, 1, CAST(N'2026-03-05T14:26:11.340' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (26, 23, 1, 1, CAST(N'2026-04-02T11:47:53.500' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (28, 1, 1, 1, CAST(N'2026-04-03T21:09:28.013' AS DateTime))
INSERT [dbo].[UserSiteAccess] ([AccessID], [UserID], [SiteID], [IsActive], [GrantedDate]) VALUES (30, 22, 1, 1, CAST(N'2026-05-17T22:31:59.600' AS DateTime))
SET IDENTITY_INSERT [dbo].[UserSiteAccess] OFF
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__CAPA__0A915F13EDD21930]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[CAPA] ADD UNIQUE NONCLUSTERED 
(
	[CAPA_Code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Departme__6EA8896D01A1FB79]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[Departments] ADD UNIQUE NONCLUSTERED 
(
	[DepartmentCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UX_QCTestResults]    Script Date: 6/7/2026 11:44:08 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [UX_QCTestResults] ON [dbo].[QCTestResults]
(
	[COAID] ASC,
	[ProductAnalysisID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Roles__D62CB59CD4B47BFE]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[Roles] ADD UNIQUE NONCLUSTERED 
(
	[RoleCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Users__1DF52D0CC09C28C2]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[Users] ADD UNIQUE NONCLUSTERED 
(
	[UserCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ__Users__A9D10534C0837289]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[Users] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UQ_UserSite]    Script Date: 6/7/2026 11:44:08 PM ******/
ALTER TABLE [dbo].[UserSiteAccess] ADD  CONSTRAINT [UQ_UserSite] UNIQUE NONCLUSTERED 
(
	[UserID] ASC,
	[SiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AnalysisCategories] ADD  CONSTRAINT [DF_AnalysisCategories_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[CAPA] ADD  DEFAULT ('MEDIUM') FOR [Priority]
GO
ALTER TABLE [dbo].[CAPA] ADD  DEFAULT ('DRAFT') FOR [StatusId]
GO
ALTER TABLE [dbo].[CAPA] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[CAPA] ADD  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[CAPA_Assignments] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[CAPA_Assignments] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[CAPAActions] ADD  DEFAULT ('PENDING') FOR [Status]
GO
ALTER TABLE [dbo].[CAPAActions] ADD  DEFAULT ('MEDIUM') FOR [Priority]
GO
ALTER TABLE [dbo].[CAPAActions] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[CAPAActionsEffectiveness] ADD  CONSTRAINT [DF_CAPAActionsEffectiveness_ActionTaken]  DEFAULT ((0)) FOR [ActionTaken]
GO
ALTER TABLE [dbo].[CAPAActionsEffectiveness] ADD  CONSTRAINT [DF_CAPAActionsEffectiveness_IsEffective]  DEFAULT ((0)) FOR [IsEffective]
GO
ALTER TABLE [dbo].[CAPAActionsEffectiveness] ADD  CONSTRAINT [DF_CAPAActionsEffectiveness_CreatedAt]  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[CAPAAssignments] ADD  DEFAULT (getdate()) FOR [AssignmentDate]
GO
ALTER TABLE [dbo].[CAPAAssignments] ADD  DEFAULT ((0)) FOR [ActionTaken]
GO
ALTER TABLE [dbo].[CAPAAssignments] ADD  DEFAULT ((0)) FOR [IsEffective]
GO
ALTER TABLE [dbo].[CAPAAssignments] ADD  DEFAULT ('ASSIGNED') FOR [Status]
GO
ALTER TABLE [dbo].[Categories] ADD  CONSTRAINT [DF_Categories_IsActve]  DEFAULT ((1)) FOR [IsActve]
GO
ALTER TABLE [dbo].[COA] ADD  CONSTRAINT [DF_COA_PreparedAt]  DEFAULT (getdate()) FOR [PreparedAt]
GO
ALTER TABLE [dbo].[Colors] ADD  CONSTRAINT [DF_Colors_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Departments] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Departments] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Departments] ADD  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[Forms] ADD  CONSTRAINT [DF_Forms_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[MenuItems] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[MenuItems] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[Packaging] ADD  CONSTRAINT [DF_Packaging_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[QCTestResults] ADD  CONSTRAINT [DF_QCTestResults_IsPassed]  DEFAULT ((0)) FOR [IsPassed]
GO
ALTER TABLE [dbo].[QCTestResults] ADD  CONSTRAINT [DF_QCTestResults_PreparedAt]  DEFAULT (getdate()) FOR [PreparedAt]
GO
ALTER TABLE [dbo].[QCTestResults] ADD  CONSTRAINT [DF_QCTestResults_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Roles] ADD  DEFAULT ((1)) FOR [RoleLevel]
GO
ALTER TABLE [dbo].[Roles] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Roles] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[RootCauses] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[RootCauses] ADD  DEFAULT ((0)) FOR [IsVerified]
GO
ALTER TABLE [dbo].[Sites] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Sites] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[Status] ADD  CONSTRAINT [DF_Status_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[UserSiteAccess] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[UserSiteAccess] ADD  DEFAULT (getdate()) FOR [GrantedDate]
GO
ALTER TABLE [dbo].[CAPA]  WITH CHECK ADD FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[CAPA]  WITH CHECK ADD FOREIGN KEY([FromDepartmentID])
REFERENCES [dbo].[Departments] ([DepartmentID])
GO
ALTER TABLE [dbo].[CAPAActions]  WITH CHECK ADD FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[CAPAActions]  WITH CHECK ADD FOREIGN KEY([RootCauseID])
REFERENCES [dbo].[RootCauses] ([RootCauseID])
GO
ALTER TABLE [dbo].[CAPAAssignments]  WITH CHECK ADD FOREIGN KEY([CAPAID])
REFERENCES [dbo].[CAPA] ([CAPAID])
GO
ALTER TABLE [dbo].[CAPAAssignments]  WITH CHECK ADD FOREIGN KEY([EffectivenessCheckedBy])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[CAPAAssignments]  WITH CHECK ADD FOREIGN KEY([RootCauseID])
REFERENCES [dbo].[RootCauses] ([RootCauseID])
GO
ALTER TABLE [dbo].[ProductAnalysis]  WITH CHECK ADD FOREIGN KEY([CategoryId])
REFERENCES [dbo].[AnalysisCategories] ([Id])
GO
ALTER TABLE [dbo].[RootCauses]  WITH CHECK ADD FOREIGN KEY([CAPAID])
REFERENCES [dbo].[CAPA] ([CAPAID])
GO
ALTER TABLE [dbo].[RootCauses]  WITH CHECK ADD FOREIGN KEY([CreatedBy])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[RootCauses]  WITH CHECK ADD FOREIGN KEY([VerifiedBy])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Users]  WITH CHECK ADD FOREIGN KEY([DepartmentID])
REFERENCES [dbo].[Departments] ([DepartmentID])
GO
ALTER TABLE [dbo].[Users]  WITH CHECK ADD FOREIGN KEY([RoleID])
REFERENCES [dbo].[Roles] ([RoleID])
GO
ALTER TABLE [dbo].[UserSiteAccess]  WITH CHECK ADD  CONSTRAINT [FK_UserSiteAccess_Site] FOREIGN KEY([SiteID])
REFERENCES [dbo].[Sites] ([SiteID])
GO
ALTER TABLE [dbo].[UserSiteAccess] CHECK CONSTRAINT [FK_UserSiteAccess_Site]
GO
ALTER TABLE [dbo].[CAPAActions]  WITH CHECK ADD CHECK  (([ActionType]='PREVENTIVE' OR [ActionType]='CORRECTIVE'))
GO
/****** Object:  StoredProcedure [dbo].[deleteUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[deleteUser]
(@UserID int)
AS

BEGIN
    IF NOT EXISTS (SELECT * FROM [Users]  WHERE UserID =@UserID )
BEGIN
    Select 'User not founds'
END
ELSE
   BEGIN
     
	 delete from  [Users] where UserID=@UserID
	 delete  from [UserRoles]  where UserID=@UserID
	 delete  from [UserSiteAccess] where UserID=@UserID

	  Select 'User has been deleted' 

   END
END
GO
/****** Object:  StoredProcedure [dbo].[GetEmailConcernDepartByCAPAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GetEmailConcernDepartByCAPAID]
(@CAPAID int)

AS
BEGIN

select EmailConcernDeparts.[DepartmentId] as Id,[DepartmentName] from EmailConcernDeparts inner join
Departments on EmailConcernDeparts.DepartmentID=Departments.DepartmentID
where CAPAID=@CAPAID
END
GO
/****** Object:  StoredProcedure [dbo].[sp_AcceptOrRecjectCAPA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_AcceptOrRecjectCAPA]
    @CAPAID INT,
    @TargetDate DATETIME = NULL,
    @ClosureDate DATETIME = NULL,
    @StatusId NVARCHAR(10),
    @CreatedBy INT,
    @RejectRemarks NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    if(@StatusId ='accept')
    begin
    
    -- Update CAPA main status
    UPDATE [TQMS].[dbo].[CAPA]
    SET StatusId =( CASE 
                  WHEN @StatusId = 'accept' THEN 6
                  WHEN @StatusId = 'reject' THEN 7
                  ELSE StatusId
               END),
        UpdatedAt = GETDATE(),
        TargetDate=@TargetDate,
        ClosureDate=@ClosureDate
        --,
       -- RejectRemarks=@RejectRemarks
    WHERE CAPAID = @CAPAID

    end

    else

    begin

        delete from [CAPA_Assignments]
    where CAPAID=@CAPAID
    
    -- Update CAPA main status
    UPDATE [TQMS].[dbo].[CAPA]
    SET StatusId =( CASE 
                  WHEN @StatusId = 'accept' THEN 6
                  WHEN @StatusId = 'reject' THEN 7
                  ELSE StatusId
               END),
        UpdatedAt = GETDATE(),
        TargetDate='',
        ClosureDate='',
        RejectRemarks=@RejectRemarks
    WHERE CAPAID = @CAPAID


    end


;

    SELECT 'SUCCESS' AS Message;
END
GO
/****** Object:  StoredProcedure [dbo].[sp_AddAction]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 3. Add Action for Root Cause
CREATE PROCEDURE [dbo].[sp_AddAction]
    @RootCauseID INT,
    @ActionType NVARCHAR(20),
    @ActionTitle NVARCHAR(255),
    @ActionDescription NVARCHAR(MAX),
    @AssignedTo INT,
    @DueDate DATE,
    @CreatedBy INT,
    @Priority NVARCHAR(20) = 'MEDIUM'
AS
BEGIN
    DECLARE @ActionCode NVARCHAR(50);
    DECLARE @CAPAID INT;
    
    SELECT @CAPAID = CAPAID FROM RootCauses WHERE RootCauseID = @RootCauseID;
    
    DECLARE @ActionCount INT;
    SELECT @ActionCount = COUNT(*) + 1 FROM CAPAActions WHERE RootCauseID = @RootCauseID;
    SET @ActionCode = 'A-' + RIGHT('000' + CAST(@ActionCount AS VARCHAR), 3);
    
    INSERT INTO CAPAActions (RootCauseID, ActionCode, ActionType, ActionTitle, ActionDescription, AssignedTo, DueDate, CreatedBy, Priority)
    VALUES (@RootCauseID, @ActionCode, @ActionType, @ActionTitle, @ActionDescription, @AssignedTo, @DueDate, @CreatedBy, @Priority);
    
    DECLARE @ActionID INT = SCOPE_IDENTITY();
    
    -- Create assignment record
    INSERT INTO CAPAAssignments (CAPAID, RootCauseID, ActionID, AssignedTo, AssignedBy, ExpectedCompletionDate)
    VALUES (@CAPAID, @RootCauseID, @ActionID, @AssignedTo, @CreatedBy, @DueDate);
    
    SELECT @ActionID AS ActionID, @ActionCode AS ActionCode;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_AddCAPAActionsEffectiveness]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_AddCAPAActionsEffectiveness]
(@RootCauseID int,
 @DetailsOfRootCause nvarchar(max),
 @CorectiveAction  nvarchar(max),
 @PreventiveAction nvarchar(max),
 @CreatedBy int,
 @CAPAID  int
)
as

INSERT INTO [CAPAActionsEffectiveness]
           ([RootCauseID]
           ,[DetailsOfRootCause]
           ,[CorectiveAction]
           ,[PreventiveAction]
           ,[CreatedBy]
           ,[CAPAID] )
        
     VALUES(@RootCauseID ,@DetailsOfRootCause,@CorectiveAction ,@PreventiveAction ,@CreatedBy ,@CAPAID)
     SELECT SCOPE_IDENTITY()
GO
/****** Object:  StoredProcedure [dbo].[sp_AddRootCause]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 2. Add Root Cause with Auto Code
CREATE PROCEDURE [dbo].[sp_AddRootCause]
    @CAPAID INT,
    @RootCauseTitle NVARCHAR(255),
    @RootCauseDetails NVARCHAR(MAX),
    @Category NVARCHAR(100),
    @CreatedBy INT
AS
BEGIN
    DECLARE @RootCauseCode NVARCHAR(50);
    DECLARE @RootCauseCount INT;
    
    SELECT @RootCauseCount = COUNT(*) + 1 FROM RootCauses WHERE CAPAID = @CAPAID;
    SET @RootCauseCode = 'RC-' + RIGHT('000' + CAST(@RootCauseCount AS VARCHAR), 3);
    
    INSERT INTO RootCauses (CAPAID, RootCauseCode, RootCauseTitle, RootCauseDetails, Category, CreatedBy)
    VALUES (@CAPAID, @RootCauseCode, @RootCauseTitle, @RootCauseDetails, @Category, @CreatedBy);
    
    SELECT SCOPE_IDENTITY() AS RootCauseID, @RootCauseCode AS RootCauseCode;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_AllCAPAActionsIsEffective]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create  procedure [dbo].[sp_AllCAPAActionsIsEffective]
(
@ActionTaken bit,
@IsEffective bit,
@VerifiedBy int,
@CAPAID  int,
@Remarks nvarchar(max)
)
as

update CAPAActionsEffectiveness
           set 
            VerifiedBy = @VerifiedBy
            ,ActionTaken=@ActionTaken
             ,IsEffective=@IsEffective
             ,VerifiedAt=GETDATE()
             ,Remarks=@Remarks
            where CAPAID=@CAPAID  

          
            update [CAPA]

            set  [StatusId]=5
              ,ClosedAt=GETDATE()

            where CAPAID=@CAPAID
GO
/****** Object:  StoredProcedure [dbo].[sp_ApprovedAllTestResultByCOAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [dbo].[sp_ApprovedAllTestResultByCOAID]
(
    @COAID INT,
    @UserID  int
)
AS
BEGIN
   
    
         UPDATE COA
         SET 
         ApprovedBy=@UserID
        ,ApprovedAt=GETDATE()
        , [Status] =10
         WHERE Id = @COAID and CheckedBy is not null
   
    
END


--exec sp_ApprovedAllTestResultByCOAID 41,1
GO
/****** Object:  StoredProcedure [dbo].[sp_AssignCAPA_MultipleUsers]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_AssignCAPA_MultipleUsers]
    @CAPAID INT,
    @UserIDs NVARCHAR(MAX), -- comma separated: '1,2,3'
    @CreatedBy INT
   
AS
BEGIN
    SET NOCOUNT ON;


    -- Convert CSV to table
    DECLARE @Users TABLE (UserID INT);

    INSERT INTO @Users(UserID)
   SELECT [Param] FROM dbo.fun_splitstring(@UserIDs)

    -- Validate users
    IF EXISTS (
        SELECT 1
        FROM @Users u
        LEFT JOIN [Users] us ON u.UserID = us.UserID
        WHERE us.UserID IS NULL OR us.IsActive = 0
    )
    BEGIN
        RAISERROR('Invalid user in list', 16, 1);
        RETURN;
    END


    delete from [CAPA_Assignments]
    where CAPAID=@CAPAID and UserID in ( SELECT [Param] FROM dbo.fun_splitstring(@UserIDs))
    
    -- Insert assignments
    INSERT INTO [CAPA_Assignments]
    (CAPAID, UserID ,CreatedBy)
    SELECT 
        @CAPAID,
        UserID,
        @CreatedBy
        
    FROM @Users;



 DECLARE @Emails NVARCHAR(max);
    
 SELECT 
    @Emails =STUFF((
        SELECT ',' + us.Email
        FROM @Users u
        INNER JOIN [Users] us 
            ON u.UserID = us.UserID
        WHERE us.IsActive = 1
        FOR XML PATH(''), TYPE
    ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') 



    SELECT 'SUCCESS' AS Message ,@Emails as Emails ;
END

--exec [sp_AssignCAPA_MultipleUsers] 1,'1,2,3' ,1
GO
/****** Object:  StoredProcedure [dbo].[sp_AssignUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 4. Assign Users (HOD)
CREATE PROCEDURE [dbo].[sp_AssignUser]
    @AssignmentID VARCHAR(20),
    @CAPAID VARCHAR(20),
    @RootCauseID VARCHAR(20),
    @AssignedTo INT,
    @AssignedToName NVARCHAR(100),
    @AssignedBy INT,
    @AssignedByName NVARCHAR(100)
AS
BEGIN
    INSERT INTO Assignments (AssignmentID, CAPAID, RootCauseID, AssignedTo, AssignedToName, AssignedBy, AssignedByName)
    VALUES (@AssignmentID, @CAPAID, @RootCauseID, @AssignedTo, @AssignedToName, @AssignedBy, @AssignedByName);
    
    SELECT * FROM Assignments WHERE AssignmentID = @AssignmentID;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_CAPA_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create PROCEDURE [dbo].[sp_CAPA_Delete]
    @CAPAID INT
AS
BEGIN
    DELETE FROM CAPA WHERE CAPAID = @CAPAID
END
GO
/****** Object:  StoredProcedure [dbo].[sp_CAPAActionsEffectiveness_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_CAPAActionsEffectiveness_Delete]
    @Id INT
AS
BEGIN
    DELETE FROM CAPAActionsEffectiveness WHERE ActionID = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Certifications_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Certifications_Delete]
    @Id INT
AS
BEGIN
    DELETE FROM Certifications WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Certifications_GetAllByProductId]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Certifications_GetAllByProductId]
(@ProductId int)
AS
BEGIN
    SELECT Certifications.Id, ProductId, CertificationName, Certifications.IsActive ,Products.ProductName
    FROM Certifications inner join  Products
    on Products.Id=Certifications.ProductId 
    
    where ProductId=@ProductId
END


--exec  [sp_Certifications_GetAllByProductId] 1
GO
/****** Object:  StoredProcedure [dbo].[sp_Certifications_Insert]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Certifications_Insert]
    @ProductId INT,
    @CertificationName NVARCHAR(200),
    @IsActive BIT
AS
BEGIN
    INSERT INTO Certifications (ProductId, CertificationName, IsActive)
    VALUES (@ProductId, @CertificationName, @IsActive)

    SELECT SCOPE_IDENTITY() AS Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Certifications_Update]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Certifications_Update]
    @Id INT,
    @ProductId INT,
    @CertificationName NVARCHAR(200),
    @IsActive BIT
AS
BEGIN
    UPDATE Certifications
    SET 
        ProductId = @ProductId,
        CertificationName = @CertificationName,
        IsActive = @IsActive
    WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_CompleteAction]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 4. Complete Action (User)
CREATE PROCEDURE [dbo].[sp_CompleteAction]
    @AssignmentID INT,
    @ActionTaken BIT,
    @Remarks NVARCHAR(MAX),
    @CompletedBy INT
AS
BEGIN
    UPDATE CAPAAssignments 
    SET ActionTaken = @ActionTaken,
        ActionTakenRemarks = @Remarks,
        ActualCompletionDate = GETDATE(),
        Status = CASE WHEN @ActionTaken = 1 THEN 'COMPLETED' ELSE 'REJECTED' END
    WHERE AssignmentID = @AssignmentID;
    
    UPDATE CAPAActions 
    SET Status = CASE WHEN @ActionTaken = 1 THEN 'COMPLETED' ELSE 'REJECTED' END,
        CompletedAt = GETDATE(),
        CompletionRemarks = @Remarks
    WHERE ActionID = (SELECT ActionID FROM CAPAAssignments WHERE AssignmentID = @AssignmentID);
    
    SELECT 'Action Completed' AS Message;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_CreateCAPA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_CreateCAPA]
    @Description NVARCHAR(MAX),
    @FromDepartmentID INT,
    @ToDepartmentID NVARCHAR(20),
    @CreatedBy INT,
    @Priority NVARCHAR(20) = 'MEDIUM',
    @TargetDate DATE = NULL,
    @ItemId NVARCHAR(50),
    @ItemVarietyID NVARCHAR(50),
    @Site NVARCHAR(10),
    @SalesId  NVARCHAR(50),
    @Customer NVARCHAR(50),
    @ItemName NVARCHAR(50)
  
AS
BEGIN
    DECLARE @CAPAID INT;
    DECLARE @CAPA_Code NVARCHAR(50);
    DECLARE @UserName NVARCHAR(50);
     DECLARE @Emails NVARCHAR(max);
    
    set @UserName= (select  FullName from [Users]  where UserID=@CreatedBy)
    
    SELECT @CAPA_Code = 'C-' + RIGHT('000' + CAST(ISNULL(MAX(CAPAID), 0) + 1 AS VARCHAR), 3)
    FROM CAPA;
    
    INSERT INTO CAPA (CAPA_Code, Description, FromDepartmentID, CreatedBy, Priority, StatusId, TargetDate, CreatedAt,ItemId,ItemVarietyID,Customer,SalesId,Site,ItemName)
    VALUES (@CAPA_Code, @Description, @FromDepartmentID, @CreatedBy, @Priority, 1, @TargetDate, GETDATE(),@ItemId,@ItemVarietyID,@Customer,@SalesId,@Site,@ItemName);
    
    SET @CAPAID = SCOPE_IDENTITY();
    
    insert into  EmailConcernDeparts([CAPAID],[DepartmentID])
    
    select @CAPAID, DepartmentID from (
    select [Param] from  dbo.fun_splitstring(@ToDepartmentID) ) as tb
    inner join Departments on LTRIM(RTRIM([Param]))=LTRIM(RTRIM(DepartmentID))
    
    
  SELECT @Emails =STUFF((
    SELECT DISTINCT ',' + d.Email
    FROM dbo.fun_splitstring(@ToDepartmentID) tb
    INNER JOIN Departments d 
        ON LTRIM(RTRIM(tb.Param)) = LTRIM(RTRIM(d.DepartmentID))
    WHERE d.Email IS NOT NULL AND d.Email <> ''
    FOR XML PATH(''), TYPE
).value('.', 'NVARCHAR(MAX)'), 1, 1, '')
    
    
    
    SELECT @CAPAID AS CAPAID, @CAPA_Code AS CAPA_Code ,@UserName as CreatedBy,@Emails as Emails;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_CreateCOA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_CreateCOA]
    
    @PreparedBy INT,
    @ItemId NVARCHAR(50),
    @LotNumber NVARCHAR(50),
    @ProductionDate  date,
    @ItemVarietyID NVARCHAR(50),
    @Site NVARCHAR(10),
    @SalesId  NVARCHAR(50),
    @ItemName NVARCHAR(50),
    @RFNItemNumber NVARCHAR(20),
    @ACCOUNTNUM NVARCHAR(20),
    @ExpiryDate date,
    @Customer NVARCHAR(50)
  
AS
BEGIN
    IF  (SELECT COUNT(*) FROM COA  WHERE SalesId  =@SalesId  and ItemId=@ItemId and ItemVarietyID=@ItemVarietyID and [Status]=1 )>0 
BEGIN
    Select 'Alreay Exists '+ 'ITEMID:'+@ItemId + ' and  SalesID :' +@SalesId 
END
ELSE
   BEGIN
    
    INSERT INTO COA(PreparedBy, PreparedAt, LotNumber,[Status] ,ItemId,ItemVarietyID,SalesId,Site,ItemName,RFNItemNumber,ACCOUNTNUM
    ,ProductionDate,ExpiryDate,Customer)


    VALUES (@PreparedBy, GETDATE(), @LotNumber,8 ,@ItemId,@ItemVarietyID,@SalesId,@Site,@ItemName
    ,@RFNItemNumber,@ACCOUNTNUM,CAST(@ProductionDate AS DATE),CAST(@ExpiryDate AS DATE),@Customer );
    
    select  'successfully inserted';
    
    END
  
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_DeleteAssignCAPAUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_DeleteAssignCAPAUser]
    @CAPAID INT,
    @AssignmentID INT
   
   
AS
BEGIN
    SET NOCOUNT ON;


    DELETE FROM CAPA_Assignments WHERE CAPAID=@CAPAID and AssignmentID=@AssignmentID


    SELECT 'SUCCESS' AS Message;
END
GO
/****** Object:  StoredProcedure [dbo].[sp_deleteQCTestResult]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[sp_deleteQCTestResult]
(@Id int)
as
begin
delete 
  FROM [TQMS].[dbo].[QCTestResults]
  where TestResultID =@Id

  end
GO
/****** Object:  StoredProcedure [dbo].[sp_GenerateQCTestResults]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  PROCEDURE [dbo].[sp_GenerateQCTestResults]
(@COAID int ,
 @PreparedBy  int,
 @ItemVarietyID nvarchar(20)
 )
AS
 

BEGIN
    IF  (SELECT COUNT(*) FROM [QCTestResults]  WHERE COAID =@COAID )>0 
BEGIN
    Select 'Alreay Exists '+ 'COAID:'+cast(@COAID as nvarchar) + ' and  ItemVarietyID :' +@ItemVarietyID 
END
ELSE
   BEGIN


insert into  [QCTestResults]([COAID],[ProductAnalysisID],[PreparedBy])
     
       
SELECT 
      [COA].[Id]  ,ProductAnalysis.Id  ,@PreparedBy
  FROM ProductAnalysis inner join [Products]
  on ProductAnalysis.ProductId=[Products].Id
  inner join [COA]    on [COA].ItemVarietyID=[Products].ItemVarietyID
where  [COA].ItemVarietyID=@ItemVarietyID and  [COA].[Id]=@COAID
       and  ProductAnalysis.IsActive=1  and [Products].IsActive=1
           
   
     
END
END

--exec   [sp_GenerateQCTestResults] 41,1,'V0040'
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAll_AnalysisCategories]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[sp_GetAll_AnalysisCategories]
as
begin
SELECT  [Id]
      ,[CategoryName]
      ,[IsActive]
  FROM [TQMS].[dbo].[AnalysisCategories]
  where IsActive=1
  end
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCAPAActionsEffectivenessByCAPAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_GetAllCAPAActionsEffectivenessByCAPAID]
(@CAPAID int)
as
SELECT [ActionID]
      ,RootCauseType.Name
      ,[RootCauseID]
      ,[DetailsOfRootCause]
      ,[CorectiveAction]
      ,[PreventiveAction]
       ,Users.FullName
      ,[CreatedBy]
      ,[CAPAID]
      ,[ActionTaken]
      ,[IsEffective]
      ,[Remarks]
      ,CAPAActionsEffectiveness.[CreatedAt]
      ,[VerifiedBy]
      ,[VerifiedAt]
  FROM  [CAPAActionsEffectiveness] inner join RootCauseType on
        CAPAActionsEffectiveness.RootCauseID=RootCauseType.ID
        inner join Users on Users.UserID= CAPAActionsEffectiveness.CreatedBy
  where CAPAID=@CAPAID
  
  
  --exec [sp_GetAllCAPAActionsEffectivenessByCAPAID] 17
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCapaAssignUsers]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_GetAllCapaAssignUsers]
 
as

 SELECT [Users].UserID, FullName ,DepartmentName,RoleName
    FROM [Users] inner join Departments
    on Departments.DepartmentID=[Users].DepartmentID
    inner join Roles on Roles.RoleID=[Users].RoleID
    inner join [CAPA_Assignments] on [CAPA_Assignments].UserID = [Users].UserID
    WHERE [Users].IsActive = 1 and [CAPA_Assignments].IsActive=1
    ORDER BY FullName
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCapaAssignUsersByCAPAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_GetAllCapaAssignUsersByCAPAID]
 ( @CAPAID INT)
as

 SELECT [CAPA_Assignments].AssignmentID, [Users].UserID, FullName ,DepartmentName,RoleName
    FROM [Users] inner join Departments
    on Departments.DepartmentID=[Users].DepartmentID
    inner join Roles on Roles.RoleID=[Users].RoleID
    inner join [CAPA_Assignments] on [CAPA_Assignments].UserID = [Users].UserID
    WHERE [Users].IsActive = 1 and [CAPA_Assignments].IsActive=1
    and CAPAID=@CAPAID
    ORDER BY FullName
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCAPAs]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 10. Get All CAPAs
CREATE PROCEDURE [dbo].[sp_GetAllCAPAs]
AS
BEGIN
    SELECT * ,(select top 1 StatusName from [Status]  where id=CAPA.StatusId) as 'Status'  FROM CAPA 
    

    
    ORDER BY CreatedAt DESC;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllCategories]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAllCategories]
AS
BEGIN
	select Id,Name
      
  FROM [Categories]
  
  where [IsActve]=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllColors]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetAllColors]
AS
BEGIN
	select [Id],[Name]
      
  FROM [Colors]
  
  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllDepartment]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetAllDepartment]
AS
BEGIN
	SELECT [DepartmentId]as Id, [DepartmentName] FROM Departments  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllForms]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetAllForms]
AS
BEGIN
	select [Id],[Name]
      
  FROM [Forms]
  
  
  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetALLITEMVARIETYID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[sp_GetALLITEMVARIETYID]
(@DATAAREAID nvarchar(10))
as
begin

declare @Site nvarchar(10)

SELECT 
     @Site= [SiteName]
   FROM  [Sites]
   where SiteID=@DATAAREAID





SELECT ITEMVARIETYID as Id,[NAME] FROM MATCOAX.dbo.InventItemVariety
WHERE DATAAREAID=@Site --and ITEMVARIETYID='v0040'
and NAME like '%DE' or  NAME like '%Protein%' or  
NAME like '%dextrose%'

end
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllowedUrls]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAllowedUrls]
    @RoleId INT
AS
BEGIN
    SELECT Url
    FROM [MenuItems] inner  join RoleMenus on  RoleMenus.MenuId=[MenuItems].Id
    WHERE RoleId = @RoleId
      AND IsActive = 1
      AND Url <> '#'
      
      order by sort
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllRoles]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAllRoles]
AS
BEGIN
	select [RoleID] as Id
         ,[RoleName]
  FROM [Roles]  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllRootCauseType]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAllRootCauseType]
AS
BEGIN
    Select ID ,Name
  FROM [RootCauseType]
  
  end
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllSites]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetAllSites]
AS
BEGIN
	SELECT [SiteID] as Id,
          [SiteName]
         ,[Description]
  FROM [Sites]  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllStatus]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetAllStatus]
AS
BEGIN
	select  Id
         ,[StatusName]
  FROM [Status]  where IsActive=1
END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAllUsers]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[sp_GetAllUsers]
as

 SELECT UserID, FullName ,DepartmentName,RoleName
    FROM [Users] inner join Departments
    on Departments.DepartmentID=[Users].DepartmentID
    inner join Roles on Roles.RoleID=[Users].RoleID
    WHERE [Users].IsActive = 1
    ORDER BY FullName
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAssignCAPAByUserID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--exec sp_GetAssignCAPAByUserID  1, null,null,20
CREATE PROCEDURE [dbo].[sp_GetAssignCAPAByUserID]
(   @UserID int,
    @Search NVARCHAR(100) = '',
    @Status NVARCHAR(50) = '',
    @PageNo INT = 1,
    @PageSize INT = 20
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Search = LTRIM(RTRIM(@Search))
    SET @Status = LTRIM(RTRIM(@Status))

    -----------------------------------
    -- Total Records
    -----------------------------------
    SELECT COUNT(*) AS TotalRecords
from [CAPA] 
inner join [CAPA_Assignments] on [CAPA].CAPAID =[CAPA_Assignments].CAPAID
and [CAPA_Assignments].UserID=@UserID
    WHERE
    (
        @Search = ''
        OR CAPA_Code LIKE '%' + @Search + '%'
        OR Customer LIKE '%' + @Search + '%'
        OR ItemName LIKE '%' + @Search + '%'
    )
    AND
    (
        @Status = ''
        OR CAST(StatusId AS NVARCHAR(50)) = @Status
    );

    -----------------------------------
    -- Paginated Records
    -----------------------------------
    ;WITH CAPA_CTE AS
    (
        SELECT
            ROW_NUMBER() OVER (ORDER BY [CAPA].CAPAID DESC) AS RowNum,

            [CAPA].*,

            (
                SELECT TOP 1 StatusName
                FROM [Status]
                WHERE ID = CAPA.StatusId
            ) AS [Status],

            (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = CAPA.CreatedBy
            ) AS CreatedByName
from [CAPA] 
inner join [CAPA_Assignments] on [CAPA].CAPAID =[CAPA_Assignments].CAPAID
and [CAPA_Assignments].UserID=@UserID

        WHERE
        (
            @Search = ''
            OR CAPA_Code LIKE '%' + @Search + '%'
            OR Customer LIKE '%' + @Search + '%'
            OR ItemName LIKE '%' + @Search + '%'
        )
        AND
        (
            @Status = ''
            OR CAST(StatusId AS NVARCHAR(50)) = @Status
        )
    )

    SELECT *
    FROM CAPA_CTE
    WHERE RowNum BETWEEN
        ((@PageNo - 1) * @PageSize) + 1
        AND (@PageNo * @PageSize)

    ORDER BY RowNum;

END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetAssignCAPAByUserIDOnlyForQA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--exec sp_GetAssignCAPAByUserID  1, null,null,20
CREATE PROCEDURE [dbo].[sp_GetAssignCAPAByUserIDOnlyForQA]
(   @UserID int,
    @Search NVARCHAR(100) = '',
    @Status NVARCHAR(50) = '',
    @PageNo INT = 1,
    @PageSize INT = 20
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Search = LTRIM(RTRIM(@Search))
    SET @Status = LTRIM(RTRIM(@Status))

    -----------------------------------
    -- Total Records
    -----------------------------------
    SELECT COUNT(*) AS TotalRecords
from [CAPA]
inner join [CAPA_Assignments] on [CAPA].CAPAID =[CAPA_Assignments].CAPAID
inner join [Users] on [Users].UserID=[CAPA_Assignments].UserID 
and [CAPA_Assignments].UserID=@UserID  and  ([Users].DepartmentID=3 or [Users].RoleID=1)
    WHERE
    (
        @Search = ''
        OR CAPA_Code LIKE '%' + @Search + '%'
        OR Customer LIKE '%' + @Search + '%'
        OR ItemName LIKE '%' + @Search + '%'
    )
    AND
    (
        @Status = ''
        OR CAST(StatusId AS NVARCHAR(50)) = @Status
    );

    -----------------------------------
    -- Paginated Records
    -----------------------------------
    ;WITH CAPA_CTE AS
    (
        SELECT
            ROW_NUMBER() OVER (ORDER BY [CAPA].CAPAID DESC) AS RowNum,

            [CAPA].*,

            (
                SELECT TOP 1 StatusName
                FROM [Status]
                WHERE ID = CAPA.StatusId
            ) AS [Status],

            (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = CAPA.CreatedBy
            ) AS CreatedByName
from [CAPA] 

inner join [CAPA_Assignments] on [CAPA].CAPAID =[CAPA_Assignments].CAPAID
inner join [Users] on [Users].UserID=[CAPA_Assignments].UserID 
and [CAPA_Assignments].UserID=@UserID  and    ([Users].DepartmentID=3 or [Users].RoleID=1)

        WHERE
        (
            @Search = ''
            OR CAPA_Code LIKE '%' + @Search + '%'
            OR Customer LIKE '%' + @Search + '%'
            OR ItemName LIKE '%' + @Search + '%'
        )
        AND
        (
            @Status = ''
            OR CAST(StatusId AS NVARCHAR(50)) = @Status
        )
    )

    SELECT *
    FROM CAPA_CTE
    WHERE RowNum BETWEEN
        ((@PageNo - 1) * @PageSize) + 1
        AND (@PageNo * @PageSize)

    ORDER BY RowNum;

END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetCAPADetails]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 11. Get Complete CAPA Details with all related data
CREATE PROCEDURE [dbo].[sp_GetCAPADetails]
    @CAPAID INT
AS
BEGIN
    -- CAPA Header with Department and Creator
    SELECT 
        c.*,(select top 1 StatusName from [Status]  where id=c.StatusId) as 'Status',
        d.DepartmentName,
        u_created.FullName AS CreatedByName,
        
(SELECT 
    STUFF((
        SELECT DISTINCT ', ' + u.FullName
        FROM CAPA_Assignments ca
        INNER JOIN Users u ON u.UserID = ca.UserID
        WHERE ca.CAPAID = @CAPAID
        FOR XML PATH(''), TYPE
    ).value('.', 'NVARCHAR(MAX)'), 1, 2, '')) AS AssignedToName

        --,
      --  u_assigned.FullName AS AssignedToName,
       -- r.RoleName AS CreatorRole
    FROM CAPA c
    LEFT JOIN Departments d ON c.FromDepartmentID = d.DepartmentID
    LEFT JOIN Users u_created ON c.CreatedBy = u_created.UserID
    --LEFT JOIN Users u_assigned ON c.AssignedTo = u_assigned.UserID
    --LEFT JOIN Roles r ON u_created.RoleID = r.RoleID
   WHERE c.CAPAID = @CAPAID;
    
    -- Root Causes with Actions
    SELECT 
        rc.RootCauseID, rc.RootCauseCode, rc.RootCauseTitle, rc.RootCauseDetails, rc.Category,
        a.ActionID, a.ActionCode, a.ActionType, a.ActionTitle, a.ActionDescription, a.Status AS ActionStatus,
        ass.AssignmentID, ass.ActionTaken, ass.IsEffective, ass.Status AS AssignmentStatus,
        u_assigned.FullName AS AssignedToName,
        u_assigned_by.FullName AS AssignedByName,
        u_completed.FullName AS CompletedByName
    FROM RootCauses rc
    LEFT JOIN CAPAActions a ON rc.RootCauseID = a.RootCauseID
    LEFT JOIN CAPAAssignments ass ON a.ActionID = ass.ActionID
    LEFT JOIN Users u_assigned ON ass.AssignedTo = u_assigned.UserID
    LEFT JOIN Users u_assigned_by ON ass.AssignedBy = u_assigned_by.UserID
    LEFT JOIN Users u_completed ON a.AssignedTo = u_completed.UserID
    WHERE rc.CAPAID = @CAPAID;
    
    -- QC Test Results
    --SELECT 
    --    qr.*,
    --    u_tested.FullName AS TestedByName,
    --    u_verified.FullName AS VerifiedByName
    --FROM QCTestResults qr
    --LEFT JOIN Users u_tested ON qr.TestedBy = u_tested.UserID
    --LEFT JOIN Users u_verified ON qr.VerifiedBy = u_verified.UserID
    --WHERE qr.CAPAID = @CAPAID;
    
    ---- COA Details with Approvers
    --SELECT 
    --    coa.*,
    --    u_prepared.FullName AS PreparedByName,
    --    u_checked.FullName AS CheckedByName,
    --    u_approved.FullName AS ApprovedByName
    --FROM COA coa
    --LEFT JOIN Users u_prepared ON coa.PreparedBy = u_prepared.UserID
    --LEFT JOIN Users u_checked ON coa.CheckedBy = u_checked.UserID
    --LEFT JOIN Users u_approved ON coa.ApprovedBy = u_approved.UserID
    --WHERE coa.CAPAID = @CAPAID;
    
    -- COA Test Results
    --SELECT * FROM COATestResults WHERE COAID IN (SELECT COAID FROM COA WHERE CAPAID = @CAPAID);
END;


-- exec [dbo].[sp_GetCAPADetails] 1
GO
/****** Object:  StoredProcedure [dbo].[sp_GetCAPADetailsWithStatus]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [dbo].[sp_GetCAPADetailsWithStatus]
    (@status NVARCHAR(50))
as
BEGIN


SELECT c.*, u.FullName as CreatedByName,d.DepartmentName ,(select top 1 StatusName from [Status]  where id=c.StatusId) as 'Status'
      FROM CAPA c
      LEFT JOIN Users u ON c.CreatedBy = u.UserID
      inner join Departments d on u.DepartmentID=d.DepartmentID
      WHERE c.StatusId =ISNULL(@status,c.StatusId)
      ORDER BY c.CreatedAt DESC

END


--exec sp_GetCAPADetailsWithStatus null
GO
/****** Object:  StoredProcedure [dbo].[sp_GetCAPAList]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_GetCAPAList]
(
    @Search NVARCHAR(100) = '',
    @Status NVARCHAR(50) = '',
    @PageNo INT = 1,
    @PageSize INT = 20
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Search = LTRIM(RTRIM(@Search))
    SET @Status = LTRIM(RTRIM(@Status))

    -----------------------------------
    -- Total Records
    -----------------------------------
    SELECT COUNT(*) AS TotalRecords
    FROM CAPA
    WHERE
    (
        @Search = ''
        OR CAPA_Code LIKE '%' + @Search + '%'
        OR Customer LIKE '%' + @Search + '%'
        OR ItemName LIKE '%' + @Search + '%'
    )
    AND
    (
        @Status = ''
        OR CAST(StatusId AS NVARCHAR(50)) = @Status
    );

    -----------------------------------
    -- Paginated Records
    -----------------------------------
    ;WITH CAPA_CTE AS
    (
        SELECT
            ROW_NUMBER() OVER (ORDER BY CAPAID DESC) AS RowNum,

            *,

            (
                SELECT TOP 1 StatusName
                FROM [Status]
                WHERE ID = CAPA.StatusId
            ) AS [Status],

            (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = CAPA.CreatedBy
            ) AS CreatedByName

        FROM CAPA

        WHERE
        (
            @Search = ''
            OR CAPA_Code LIKE '%' + @Search + '%'
            OR Customer LIKE '%' + @Search + '%'
            OR ItemName LIKE '%' + @Search + '%'
        )
        AND
        (
            @Status = ''
            OR CAST(StatusId AS NVARCHAR(50)) = @Status
        )
    )

    SELECT *
    FROM CAPA_CTE
    WHERE RowNum BETWEEN
        ((@PageNo - 1) * @PageSize) + 1
        AND (@PageNo * @PageSize)

    ORDER BY RowNum;

END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetCOA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--exec sp_GetCOA  null,null,20
CREATE PROCEDURE [dbo].[sp_GetCOA]
(  -- @UserID int,
    @Search NVARCHAR(100) = '',
    @Status NVARCHAR(50) = '',
    @PageNo INT = 1,
    @PageSize INT = 20
)
AS
BEGIN
    SET NOCOUNT ON;

    SET @Search = LTRIM(RTRIM(@Search))
    SET @Status = LTRIM(RTRIM(@Status))

    -----------------------------------
    -- Total Records
    -----------------------------------
    SELECT COUNT(*) AS TotalRecords
  from  COA
    
--from [CAPA]
--inner join [CAPA_Assignments] on [CAPA].CAPAID =[CAPA_Assignments].CAPAID
--inner join [Users] on [Users].UserID=[CAPA_Assignments].UserID 
--and [CAPA_Assignments].UserID=@UserID  

--and  ([Users].DepartmentID=3 or [Users].RoleID=1)
    WHERE
    (
        @Search = ''
        OR LotNumber LIKE '%' + @Search + '%'
       
         OR SalesId LIKE '%' + @Search + '%'
         OR ACCOUNTNUM LIKE '%' + @Search + '%'
      
         OR ItemId LIKE '%' + @Search + '%'
         
        OR ItemName LIKE '%' + @Search + '%'
    )
    AND
    (
        @Status = '' OR [Status]   =@Status 
    );

    -----------------------------------
    -- Paginated Records
    -----------------------------------
    ;WITH CAPA_CTE AS
    (
        SELECT
            ROW_NUMBER() OVER (ORDER BY [COA].Id DESC) AS RowNum,

            [COA].*,

            (
                SELECT TOP 1 StatusName
                FROM [Status]
                WHERE ID = COA.[Status]
            ) AS [StatusName],

            (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.PreparedBy
            ) AS CreatedByName
            
             from  [COA]
    
  WHERE
    (
        @Search = ''
        OR LotNumber LIKE '%' + @Search + '%'
        
        OR SalesId LIKE '%' + @Search + '%'
         OR ACCOUNTNUM LIKE '%' + @Search + '%'
     
         OR ItemId LIKE '%' + @Search + '%'
         
        OR ItemName LIKE '%' + @Search + '%'
    )
    AND
    (
       @Status = '' OR  [Status]   = @Status 
    )
    )

    SELECT *
    FROM CAPA_CTE
    WHERE RowNum BETWEEN
        ((@PageNo - 1) * @PageSize) + 1
        AND (@PageNo * @PageSize)

    ORDER BY RowNum;

END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetCOADetails]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 11. Get Complete CAPA Details with all related data
CREATE PROCEDURE [dbo].[sp_GetCOADetails]
    @Id INT
AS
BEGIN
   SELECT
            ROW_NUMBER() OVER (ORDER BY [COA].Id DESC) AS RowNum,

            [COA].*,

            (
                SELECT TOP 1 StatusName
                FROM [Status]
                WHERE ID = COA.[Status]
            ) AS [StatusName],

            (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.PreparedBy
            ) AS CreatedByName
            ,
            
             (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.CheckedBy
            ) AS CheckedByName
            
            ,
            
             (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.ApprovedBy
            )   AS ApprovedByName
            
            
            
             from  [COA]
    
  WHERE Id=@Id
   
END;


-- exec [dbo].[sp_GetCOADetails] 41
GO
/****** Object:  StoredProcedure [dbo].[sp_GetDashboardData]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetDashboardData]
    @fromdate DATE = NULL,
    @toDate   DATE = NULL
AS
BEGIN

    -- If NULL ? default to current year (compatible with older SQL Server)
    IF @fromdate IS NULL OR @toDate IS NULL
    BEGIN
        SET @fromdate = CAST(CAST(YEAR(GETDATE()) AS VARCHAR(4)) + '-01-01' AS DATE);
        SET @toDate   = CAST(CAST(YEAR(GETDATE()) AS VARCHAR(4)) + '-12-31' AS DATE);
    END

    -- 1. Monthly Complaints
    SELECT
        DATENAME(MONTH, CreatedAt) AS Months,
        COUNT(CAPAID) AS NoOfComplaints
    FROM CAPA
    WHERE CreatedAt BETWEEN @fromdate AND @toDate
    GROUP BY
        MONTH(CreatedAt),
        DATENAME(MONTH, CreatedAt)
    ORDER BY
        MONTH(CreatedAt);

    -- 2. Product wise Complaints
    SELECT
        ItemName AS Products,
        COUNT(ItemName) AS NoOfComplaints
    FROM CAPA
    WHERE CreatedAt BETWEEN @fromdate AND @toDate
    GROUP BY ItemName;

END
GO
/****** Object:  StoredProcedure [dbo].[sp_GetDetailsBySalesId]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  procedure [dbo].[sp_GetDetailsBySalesId]
(@SalesId nvarchar(max),
 @DataAreaid  nvarchar(10))
as

declare @Site nvarchar(10)

select 
      
     @Site=[SiteName]
       FROM [Sites]
       where [SiteID]=@DataAreaid
       and IsActive=1


select ct.ACCOUNTNUM ,ct.NAME from [MATCOAX].[dbo].CustTable as ct inner join [MATCOAX].[dbo].SalesTable as st
on ct.ACCOUNTNUM=st.CUSTACCOUNT and ct.DataAreaid=st.DataAreaid 
where ct.DataAreaid=@Site and BLOCKED!=2 --and CURRENCY='PKR' 

and REPLACE(LOWER(st.SalesId), 'sop-', '') = LOWER(@SalesId)



select  sln.SalesId as SALESID,sln.ITEMID ,sln.NAME  as LineNAME,
 It.ITEMNAME as NAME  ,Iv.NAME as ItemVarityName ,It.ITEMVARIETYID

  from [MATCOAX].[dbo].SalesTable as st inner join [MATCOAX].[dbo].SalesLine as  
sln  on  St.SALESID=sln.SALESID and  st.DataAreaid=sln.DataAreaid inner join
  [MATCOAX].[dbo].InventTable as It  on It.ITEMID=sln.ITEMID  and It.DataAreaid=sln.DataAreaid 
inner join [MATCOAX].[dbo].InventItemVariety as Iv on  It.ITEMVARIETYID=Iv.ITEMVARIETYID
and Iv.DATAAREAID=It.DATAAREAID

where sln.DataAreaid=@Site and REPLACE(LOWER(sln.SalesId), 'sop-', '') = LOWER(@SalesId)



--sln.DataAreaid='rgd'  and sln.SalesId='SOP-014465'

--exec sp_GetDetailsBySalesId  '013595' , '1'
GO
/****** Object:  StoredProcedure [dbo].[sp_GetMenusByRole]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_GetMenusByRole]
    @RoleID NVARCHAR(50)
AS
BEGIN
    -- MENUS
    SELECT 
        M.Id,
        M.Title,
        M.Url,
        M.ParentId,
        M.Icon
    FROM MenuItems M
    JOIN RoleMenus RM ON M.Id = RM.MenuId
    WHERE RM.RoleId = @RoleId
      AND M.IsActive = 1
      order by sort 

    ---- PERMISSIONS
    --SELECT RP.PermissionId
    --FROM Permissions P
    --JOIN RolePermissions RP ON P.Id = RP.PermissionId
    --WHERE RP.RoleId = @RoleId;
      
END


-- exec [sp_GetMenusByRole] 1
GO
/****** Object:  StoredProcedure [dbo].[sp_GetProductDetailByID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[sp_GetProductDetailByID]
(@Id int)
as
SELECT Products.[Id]
      ,[ProductName]
      ,[ProductCode]
      ,[CategoryID]
      ,[FormID]
      ,[ColorID]
      ,Forms.Name as FormName
       ,Colors.Name as ColorName
        ,Categories.Name as CategoryName
      ,[CountryOfOrigin]
      ,[Ingredients]
      ,[IngredientsDeclaration]
      ,[SuitableFor]
      ,[Additives]
      ,[Functionalities]
      ,[Description]
      ,[ShelfLife]
      ,[StorageConditions]
      ,[Uses]
      ,[CreatedAt]
      ,ItemVarietyID 
      ,Products.[IsActive] as IsActive
  FROM Products inner join Forms on  Forms.Id=Products.FormID
  inner join Colors on  Colors.Id=Products.ColorID
  inner join Categories on  Categories.Id=Products.CategoryID 
  where  Products.[Id]=@Id
  
  
 -- exec sp_GetProductDetailByID 1
GO
/****** Object:  StoredProcedure [dbo].[sp_GetUserAssignments]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 12. Get Assignments by User
CREATE PROCEDURE [dbo].[sp_GetUserAssignments]
    @UserID INT
AS
BEGIN
    SELECT a.*, c.Title as CAPATitle, rc.RootCauseTitle
    FROM Assignments a
    JOIN CAPA c ON a.CAPAID = c.CAPAID
    JOIN RootCauses rc ON a.RootCauseID = rc.RootCauseID
    WHERE a.AssignedTo = @UserID AND a.ActionTaken = 0
    ORDER BY a.AssignedAt DESC;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_GetUsersByRoleAndDept]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 12. Get Users by Role and Department
CREATE PROCEDURE [dbo].[sp_GetUsersByRoleAndDept]
    @RoleID INT = NULL,
    @DepartmentID INT = NULL
AS
BEGIN
    SELECT 
        u.UserID, u.UserCode, u.FullName, u.Email, u.PhoneNumber,
        r.RoleID, r.RoleName, r.RoleCode,
        d.DepartmentID, d.DepartmentName, d.DepartmentCode
    FROM Users u
    INNER JOIN Roles r ON u.RoleID = r.RoleID
    INNER JOIN Departments d ON u.DepartmentID = d.DepartmentID
    WHERE u.IsActive = 1
    AND (@RoleID IS NULL OR u.RoleID = @RoleID)
    AND (@DepartmentID IS NULL OR u.DepartmentID = @DepartmentID)
    ORDER BY d.DepartmentName, r.RoleLevel DESC, u.FullName;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_LoginUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_LoginUser]
    @Email NVARCHAR(100),
    @SiteID NVARCHAR(10)
AS
BEGIN
    SELECT U.UserID, U.FullName as Username, U.Email, U.PasswordHash, R.RoleName ,UR.RoleId ,UA.SiteID , U.DepartmentId
    FROM Users U
    JOIN Roles UR ON U.RoleID = UR.RoleID
    JOIN Roles R ON UR.RoleId = R.RoleID
    inner join UserSiteAccess UA on  UA.UserId=U.UserID
    WHERE U.Email =@Email AND U.IsActive = 1  and UA.SiteID=@SiteID
    and UA.IsActive = 1 
END;



--exec [sp_LoginUser] 'muhammad.ali@matcofoods.com.pk' ,1
GO
/****** Object:  StoredProcedure [dbo].[sp_Packaging_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Packaging_Delete]
    @Id INT
AS
BEGIN
    DELETE FROM Packaging WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Packaging_GetAllByProductId]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_Packaging_GetAllByProductId]
(@ProductId int)
AS
BEGIN
    SELECT Packaging.Id, ProductId, Material,NetWeight, Packaging.IsActive ,Products.ProductName
    FROM Packaging inner join  Products
    on Products.Id=Packaging.ProductId 
    
    where ProductId=@ProductId
END


--exec  [sp_Packaging_GetAllByProductId] 1
GO
/****** Object:  StoredProcedure [dbo].[sp_Packaging_Insert]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Packaging_Insert]
    @ProductId INT,
    @Material NVARCHAR(200),
     @NetWeight  NVARCHAR(200),
    @IsActive BIT
AS
BEGIN
    INSERT INTO Packaging (ProductId, Material,NetWeight, IsActive)
    VALUES (@ProductId, @Material,@NetWeight, @IsActive)

    SELECT SCOPE_IDENTITY() AS Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Packaging_Update]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Packaging_Update]
    @Id INT,
    @ProductId INT,
    @Material NVARCHAR(200),
    @NetWeight NVARCHAR(200),
    @IsActive BIT
AS
BEGIN
    UPDATE Packaging
    SET 
        ProductId = @ProductId,
        Material = @Material,
        NetWeight=@NetWeight,
        IsActive = @IsActive
    WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_Product_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Product_Delete]
    @Id INT
AS


BEGIN
    IF NOT EXISTS (SELECT * FROM Products  WHERE Id =@Id )
BEGIN
    Select 'Product not founds'
END
ELSE
   BEGIN
   
   
   
DECLARE @count INT = 0;
DECLARE @msg NVARCHAR(MAX) = '';

-- COUNT TOTAL RECORDS
SELECT @count =
    (SELECT COUNT(*) FROM Certifications WHERE ProductId = @Id) +
    (SELECT COUNT(*) FROM Packaging WHERE ProductId = @Id) +
    (SELECT COUNT(*) FROM ProductAnalysis WHERE ProductId = @Id);

-- BUILD MESSAGE
IF EXISTS (SELECT 1 FROM Certifications WHERE ProductId = @Id)
    SET @msg = @msg + 'Certifications, ';

IF EXISTS (SELECT 1 FROM Packaging WHERE ProductId = @Id)
    SET @msg = @msg + 'Packaging, ';

IF EXISTS (SELECT 1 FROM ProductAnalysis WHERE ProductId = @Id)
    SET @msg = @msg + 'ProductAnalysis, ';

-- REMOVE LAST COMMA
IF LEN(@msg) > 0
    SET @msg = LEFT(@msg, LEN(@msg) - 2); -- remove ", "


   if(@count >0)
   begin
   select 'Delete records from : ' + @msg
   end
   
   else
   begin
     
	  DELETE FROM Products WHERE Id = @Id
	  Select 'Product has been deleted' 
	  
	  end

   END
END


--exec sp_Product_Delete 19
GO
/****** Object:  StoredProcedure [dbo].[sp_Product_Insert]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Product_Insert]


  (         @ProductName nvarchar(200)
           ,@ProductCode nvarchar(50)
           ,@CategoryID int
           ,@FormID int
           ,@ColorID int
           ,@CountryOfOrigin  nvarchar(100)
           ,@Ingredients  nvarchar(max)
           ,@IngredientsDeclaration  nvarchar(max)
           ,@SuitableFor  nvarchar(200)
           ,@Additives  nvarchar(200)
           ,@Functionalities  nvarchar(200)
           ,@Description  nvarchar(max)
           ,@ShelfLife nvarchar(200)
           ,@StorageConditions nvarchar(max)
           ,@Uses nvarchar(max)
           ,@IsActive  bit
           ,@ItemVarietyID nvarchar(10)
           )
 
 as 
 Begin
  INSERT INTO [dbo].[Products]
           ([ProductName]
           ,[ProductCode]
           ,[CategoryID]
           ,[FormID]
           ,[ColorID]
           ,[CountryOfOrigin]
           ,[Ingredients]
           ,[IngredientsDeclaration]
           ,[SuitableFor]
           ,[Additives]
           ,[Functionalities]
           ,[Description]
           ,[ShelfLife]
           ,[StorageConditions]
           ,[Uses]
           ,[IsActive]
           ,ItemVarietyID )
     VALUES
           (@ProductName
           ,@ProductCode
           ,@CategoryID
           ,@FormID
           ,@ColorID
           ,@CountryOfOrigin
           ,@Ingredients
           ,@IngredientsDeclaration
           ,@SuitableFor
           ,@Additives
           ,@Functionalities
           ,@Description
           ,@ShelfLife
           ,@StorageConditions
           ,@Uses
           ,@IsActive
           ,@ItemVarietyID 
           )

           SELECT SCOPE_IDENTITY() AS Id


           end
GO
/****** Object:  StoredProcedure [dbo].[sp_Product_Update]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_Product_Update]


  (         
            @Id int,
            @ProductName nvarchar(200)
           ,@ProductCode nvarchar(50)
           ,@CategoryID int
           ,@FormID int
           ,@ColorID int
           ,@CountryOfOrigin  nvarchar(100)
           ,@Ingredients  nvarchar(max)
           ,@IngredientsDeclaration  nvarchar(max)
           ,@SuitableFor  nvarchar(200)
           ,@Additives  nvarchar(200)
           ,@Functionalities  nvarchar(200)
           ,@Description  nvarchar(max)
           ,@ShelfLife nvarchar(200)
           ,@StorageConditions nvarchar(max)
           ,@Uses nvarchar(max)
           ,@IsActive  bit
             ,@ItemVarietyID nvarchar(10)
           )
 
 as 
 Begin
 update [dbo].[Products]
 
 set 
           [ProductName] =@ProductName
           ,[ProductCode]=@ProductCode
           ,[CategoryID]=@CategoryID
           ,[FormID]=@FormID
           ,[ColorID]=@ColorID
           ,[CountryOfOrigin]=@CountryOfOrigin
           ,[Ingredients]=@Ingredients
           ,[IngredientsDeclaration]=@IngredientsDeclaration
           ,[SuitableFor]=@SuitableFor
           ,[Additives]=@Additives
           ,[Functionalities]=@Functionalities
           ,[Description]=@Description
           ,[ShelfLife]=@ShelfLife
           ,[StorageConditions]=@StorageConditions
           ,[Uses]=@Uses
           ,[IsActive]=@IsActive
            ,ItemVarietyID=@ItemVarietyID            
           where Id=@Id
     


           end
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductAnalysis_Delete]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_ProductAnalysis_Delete]
    @Id INT
AS
BEGIN
    DELETE FROM ProductAnalysis WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductAnalysis_GetAllByProductId]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_ProductAnalysis_GetAllByProductId]
(@ProductId int)
AS
BEGIN
SELECT ProductAnalysis.Id
      ,[ProductId]
      ,[CategoryId],
       CategoryName
      ,[ParameterName]
      ,[Unit]
      ,[Limits]
      --,[Status]
      ,Method
      ,ProductAnalysis.IsActive
  FROM ProductAnalysis  inner join AnalysisCategories
  on ProductAnalysis.CategoryId=AnalysisCategories.Id
  where ProductId=@ProductId

  order by CategoryName
  
  end
  
  -- exec  sp_ProductAnalysis_GetAllByProductId 1
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductAnalysis_GetAllTestResultbyCOAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_ProductAnalysis_GetAllTestResultbyCOAID]
(@COAID int )
AS
BEGIN
SELECT 
    [QCTestResults].TestResultID,
    [ProductId],
    IsPassed,
    ProductAnalysis.[CategoryId],
    CategoryName,
    [ParameterName],
    [Unit],
    [Limits],
    [QCTestResults].Result,
    Method,
    [QCTestResults].IsActive,
    CheckedBy
FROM ProductAnalysis  
INNER JOIN AnalysisCategories
    ON ProductAnalysis.CategoryId = AnalysisCategories.Id
INNER JOIN [Products]
    ON ProductAnalysis.ProductId = [Products].Id
INNER JOIN [COA]
    ON [COA].ItemVarietyID = [Products].ItemVarietyID
INNER JOIN [QCTestResults]
    ON [QCTestResults].ProductAnalysisID = ProductAnalysis.Id
WHERE 
    [COA].[Id] = @COAID
    AND ProductAnalysis.IsActive = 1  
    AND [Products].IsActive = 1
ORDER BY 
    CASE 
        WHEN CategoryName = 'Heavy Metals' THEN 1
        ELSE 0
    END,
    CategoryName;

  SELECT  [Id]
      ,[Name]
      ,[Address1]
      ,[Address2]
      ,[ContactTell]
      ,[ContactCell]
      ,[Fax]
      ,[Email]
      ,[Code]
      ,[IssueNo]
      ,[Title]
  FROM [CompanyInfo]




  SELECT  [COA].[Id],

   (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.PreparedBy
            ) AS CreatedByName
            ,
            
             (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.CheckedBy
            ) AS CheckedByName
            
            ,
            
             (
                SELECT TOP 1 FullName
                FROM Users
                WHERE UserID = COA.ApprovedBy
            )   AS ApprovedByName
            
      ,[PreparedBy]
      ,[CheckedBy]
      ,[ApprovedBy]
      ,[Status]
      ,[PreparedAt]
      ,[CheckedAt]
      ,[ApprovedAt]
      ,[LotNumber]
      ,[ProductionDate]
      ,[ItemId]
      ,[COA].[ItemVarietyID]
      ,[SalesId]
      ,[Site]
      ,[ItemName]
      ,[RFNItemNumber]
      ,[ACCOUNTNUM]
      ,[ExpiryDate]
      ,[ProductName]
      ,[ProductCode]
      ,CountryOfOrigin
  FROM [COA] inner join 
  [Products] on [Products].[ItemVarietyID]=[COA].[ItemVarietyID]

  where [COA].[Id]=@COAID
  
  end
  
  -- exec  sp_ProductAnalysis_GetAllTestResultbyCOAID 41
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductAnalysis_Insert]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_ProductAnalysis_Insert]
    @ProductId INT,
    @CategoryId int,
    @ParameterName  NVARCHAR(200),
    @Unit NVARCHAR(50),
    @Limits NVARCHAR(50),
   -- @Status NVARCHAR(50),
    @IsActive BIT,
    @Method NVARCHAR(max)
AS
BEGIN
    INSERT INTO ProductAnalysis (ProductId, CategoryId,ParameterName,Unit ,Limits, IsActive,Method)
    VALUES (@ProductId, @CategoryId,@ParameterName,@Unit,@Limits , @IsActive,@Method)

    SELECT SCOPE_IDENTITY() AS Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductAnalysis_Update]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_ProductAnalysis_Update]
    @Id INT,
    @ProductId INT,
    @CategoryId int,
    @ParameterName  NVARCHAR(200),
    @Unit NVARCHAR(50),
    @Limits NVARCHAR(50),
    --@Status NVARCHAR(50),
    @IsActive BIT,
    @Method NVARCHAR(max)
AS
BEGIN
    UPDATE ProductAnalysis
    SET 
        ProductId = @ProductId,
        CategoryId = @CategoryId,
        ParameterName=@ParameterName,
        Unit=@Unit,
        Limits=@Limits,
      --  [Status]=@Status,
        IsActive = @IsActive,
        Method=@Method
    WHERE Id = @Id
END
GO
/****** Object:  StoredProcedure [dbo].[sp_ProductsPagination]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_ProductsPagination]
    @page        INT,
    @size        INT,
    @search      NVARCHAR(MAX) = '',
    @orderBy     NVARCHAR(MAX) = 'Id',
    @orderDir    NVARCHAR(MAX) = 'DESC'
AS
BEGIN
    SET NOCOUNT ON;
    
    DECLARE @skip INT = (@size * @page) - @size;
    DECLARE @sql NVARCHAR(MAX);
    DECLARE @whereClause NVARCHAR(MAX) = '';
    
    
    -- Build WHERE clause if search is provided
    IF LTRIM(RTRIM(@search)) <> ''
    BEGIN
        SET @whereClause = N'WHERE LOWER(ProductName) LIKE ''%'' + LOWER(@search) + ''%''
                           OR LOWER(ProductCode) LIKE ''%'' + LOWER(@search) + ''%''  
                            OR LOWER(Categories.Name) LIKE ''%'' + LOWER(@search) + ''%'' 
                           
                              ';
    END
    
    -- Build complete query using ROW_NUMBER
    SET @sql = N'
    WITH PaginatedProduts AS (
        SELECT 
            U.*,Categories.Name as CategoryName ,


            ROW_NUMBER() OVER 
            (ORDER BY U.' + QUOTENAME(@orderBy) + ' ' + @orderDir + ') AS RowNum

        FROM dbo.Products U   inner join Categories on  Categories.Id=U.CategoryID 
        
       
        ' + @whereClause + '
    )

    SELECT * 
    FROM PaginatedProduts
    WHERE RowNum BETWEEN ' + CAST(@skip + 1 AS NVARCHAR(20)) + ' 
    AND ' + CAST(@skip + @size AS NVARCHAR(20)) + ';

    SELECT 
        (SELECT COUNT(*) FROM dbo.Products U ' + @whereClause + ') AS Filtered,
        (SELECT COUNT(*) FROM dbo.Products) AS Total;';
    -- Execute the query
    EXEC sp_executesql @sql, N'@search NVARCHAR(MAX)', @search;
END


--EXEC [sp_ProductsPagination] @page = 1, @size = 5
--EXEC [sp_ProductsPagination] @page = 1, @size = 1, @search = 'a'
--EXEC [sp_ProductsPagination] @page = 1, @size = 5, @search = 'a', @orderBy = 'ProductName', @orderDir = 'ASC'
--EXEC [sp_ProductsPagination] @page = 1, @size = 5, @search = '', @orderBy = 'ProductName', @orderDir = 'ASC'
GO
/****** Object:  StoredProcedure [dbo].[sp_RefreshAgainGenerateQCTestResults]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create  PROCEDURE [dbo].[sp_RefreshAgainGenerateQCTestResults]
(@COAID int ,
 @PreparedBy  int,
 @ItemVarietyID nvarchar(20)
 )
AS
 

BEGIN


DELETE Q
FROM QCTestResults Q
INNER JOIN ProductAnalysis PA 
    ON Q.ProductAnalysisID = PA.Id
INNER JOIN Products P 
    ON PA.ProductId = P.Id
INNER JOIN COA C 
    ON Q.COAID = C.Id
WHERE 
    C.ItemVarietyID = @ItemVarietyID
    AND C.Id = @COAID
    AND (PA.IsActive = 0 OR P.IsActive = 0);


    INSERT INTO QCTestResults (COAID, ProductAnalysisID, PreparedBy)
SELECT 
    C.Id,
    PA.Id,
    @PreparedBy
FROM ProductAnalysis PA
INNER JOIN Products P
    ON PA.ProductId = P.Id
INNER JOIN COA C
    ON C.ItemVarietyID = P.ItemVarietyID
WHERE 
    C.ItemVarietyID = @ItemVarietyID
    AND C.Id = @COAID
    AND PA.IsActive = 1
    AND P.IsActive = 1
    AND NOT EXISTS (
        SELECT 1 
        FROM QCTestResults Q
        WHERE Q.COAID = C.Id
          AND Q.ProductAnalysisID = PA.Id
    );

end
GO
/****** Object:  StoredProcedure [dbo].[sp_RegisterUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_RegisterUser]
   
 (
 @username nvarchar(50),
 @email nvarchar(50),
 @passwordhash nvarchar(225),
 @rawpassword nvarchar(50),
 @role_id int,
 @departmentId int,
 @site_Ids nvarchar(50),
 @isActive bit

)
AS

BEGIN
    IF EXISTS (SELECT COUNT(*) FROM [Users]  WHERE email =@email  )
BEGIN
    Select 'Email Exists'
END
ELSE
   BEGIN
      insert into [Users](FullName,email,PasswordHash,RawPassword,isActive,DepartmentId  ) 
	  values(@username,@email,@passwordhash,@rawpassword,@isActive,@departmentId )

-- Capture first identity
DECLARE @UserID int = SCOPE_IDENTITY();

 insert into [UserSiteAccess]([UserID],[SiteID],[IsActive])
 
 --select @UserID,(select SiteID  from [Sites] where SiteCode= [Param] ), 1 from dbo.fun_splitstring(@site_Ids)
 
 
select @UserID,SiteID,1 from (
select [Param] from  dbo.fun_splitstring(@site_Ids) ) as tb
inner join [Sites] on LTRIM(RTRIM([Param]))=LTRIM(RTRIM(SiteID))



insert into [UserRoles]([UserID],[RoleID])

select  @UserID ,@role_id
 


	  Select 'New user has been created'

   END
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateCAPA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_UpdateCAPA]
    @CAPAID INT,
    @Description NVARCHAR(MAX),
    @FromDepartmentID INT,
    @ToDepartmentID NVARCHAR(20),
    @ItemId NVARCHAR(50),
    @ItemVarietyID NVARCHAR(50),
    @Site NVARCHAR(10),
    @SalesId  NVARCHAR(50),
    @Customer NVARCHAR(50),
    @ItemName NVARCHAR(50)
  
AS
BEGIN
  
    
    update  CAPA  set  Description =@Description
    , FromDepartmentID=@FromDepartmentID
    ,ItemId =@ItemId
    ,ItemVarietyID =@ItemVarietyID
    ,Customer =@Customer
    ,SalesId =@SalesId
    ,Site =@Site ,
    ItemName =@ItemName
    
    where CAPAID=@CAPAID

    
 
    delete from EmailConcernDeparts
    where [CAPAID]=@CAPAID
    
    insert into  EmailConcernDeparts([CAPAID],[DepartmentID])
    
    select @CAPAID, DepartmentID from (
    select [Param] from  dbo.fun_splitstring(@ToDepartmentID) ) as tb
    inner join Departments on LTRIM(RTRIM([Param]))=LTRIM(RTRIM(DepartmentID))
    
    
    
    SELECT @CAPAID AS CAPAID ;
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateCAPAActionsEffectiveness]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  procedure [dbo].[sp_UpdateCAPAActionsEffectiveness]
(
@ActionID int,
@RootCauseID int,
 @DetailsOfRootCause nvarchar(max),
 @CorectiveAction  nvarchar(max),
 @PreventiveAction nvarchar(max),
 @CreatedBy int,
 @CAPAID  int
)
as

update CAPAActionsEffectiveness
           set [RootCauseID]=@RootCauseID 
           ,[DetailsOfRootCause]=@DetailsOfRootCause
           ,[CorectiveAction]=@CorectiveAction
           ,[PreventiveAction]=@PreventiveAction
           ,UpdatedBy= @CreatedBy
           where CAPAID=@CAPAID  and ActionID=@ActionID
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateCAPAActionsIsEffective]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE  procedure [dbo].[sp_UpdateCAPAActionsIsEffective]
(
@ActionID int,
@ActionTaken bit,
@IsEffective bit,
@VerifiedBy int,
@CAPAID  int,
@Remarks nvarchar(max)
)
as

update CAPAActionsEffectiveness
           set 
            VerifiedBy = @VerifiedBy
            ,ActionTaken=@ActionTaken
             ,IsEffective=@IsEffective
             ,VerifiedAt=GETDATE()
             ,Remarks=@Remarks
            where CAPAID=@CAPAID  and ActionID=@ActionID

            if( select  count(*)  from CAPAActionsEffectiveness where CAPAID=@CAPAID  and VerifiedBy is null) =0
            begin

            update [CAPA]

            set  [StatusId]=5
              ,ClosedAt=GETDATE()

            where CAPAID=@CAPAID
            end

            else
            begin

            
            update [CAPA]

            set  [StatusId]=6
            ,ClosedAt=null

            where CAPAID=@CAPAID

            end
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateCOA]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[sp_UpdateCOA]
    
    @PreparedBy INT,
    @ItemId NVARCHAR(50),
    @LotNumber NVARCHAR(50),
    @ProductionDate  date,
    @ItemVarietyID NVARCHAR(50),
    @Site NVARCHAR(10),
    @SalesId  NVARCHAR(50),
    @ItemName NVARCHAR(50),
    @RFNItemNumber NVARCHAR(20),
    @ACCOUNTNUM NVARCHAR(20),
    @ExpiryDate date,
    @customer NVARCHAR(50)
  
AS
BEGIN

    
    update COA
    set PreparedBy=@PreparedBy, 
    LotNumber=@LotNumber,
    ItemId=@ItemId,
    ItemVarietyID=@ItemVarietyID,
    SalesId=@SalesId,
    Site=@Site,
    ItemName=@ItemName,
    RFNItemNumber=@RFNItemNumber,
    ACCOUNTNUM=@ACCOUNTNUM,
    ProductionDate=CAST(@ProductionDate AS DATE),
    ExpiryDate=CAST(@ExpiryDate AS DATE) ,
    Customer=@Customer
   
   

    
    select  'successfully updated';
    
    
  
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateSingleFieldQATestResult]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [dbo].[sp_UpdateSingleFieldQATestResult]
(
    @Id INT,
    @FieldName NVARCHAR(50),
    @Value NVARCHAR(MAX),
    @UserID  int,
    @COAID int
)
AS
BEGIN
    IF @FieldName = 'Result'
    BEGIN
        UPDATE QCTestResults
        SET Result = @Value
        WHERE TestResultID = @Id;
    END

    IF @FieldName = 'IsActive'
    BEGIN
        UPDATE QCTestResults
        SET IsActive = CAST(@Value AS BIT)
        WHERE TestResultID = @Id;
    END

    
    IF @FieldName = 'IsPassed'
    BEGIN
        UPDATE QCTestResults
        SET IsPassed = CAST(@Value AS BIT),
        VerifiedBy=@UserID
        ,VerifiedAt=GETDATE()
        WHERE TestResultID = @Id;

        if(select count(*) from QCTestResults where IsPassed=0 and COAID=@COAID )=0
        begin

         UPDATE COA
         SET 
         CheckedBy=@UserID
        ,CheckedAt=GETDATE()
          ,[Status] =9
         WHERE Id = @COAID;
         end

         else
         begin
          UPDATE COA
         SET 
         CheckedBy=null
        ,CheckedAt=null
        ,[Status] =8
         WHERE Id = @COAID;
         end
    END
    
END
GO
/****** Object:  StoredProcedure [dbo].[sp_UpdateUser]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create PROCEDURE [dbo].[sp_UpdateUser]
   
 (
 @UserID int,
 @username nvarchar(50),
 @email nvarchar(50),
 @passwordhash nvarchar(225),
 @rawpassword nvarchar(50),
 @role_id int,
 @departmentId int,
 @site_Ids nvarchar(50),
 @isActive bit

)
AS

BEGIN
    IF NOT EXISTS (SELECT * FROM [Users]  WHERE  UserID=@UserID )
BEGIN
    Select 'User does not exists'
END
ELSE
   BEGIN
      
	  
	  update [Users]  set  FullName=@username  ,email=@email ,PasswordHash= @passwordhash,
	                       RawPassword=RawPassword, isActive=@isActive  ,DepartmentId=@departmentId  ,RoleID=@role_id
	                       where  UserID=@UserID 
	                       
	                       
	                        
delete from [UserSiteAccess] where [UserID]=@UserID

 insert into [UserSiteAccess]([UserID],[SiteID],[IsActive])
 
 --select @UserID,(select SiteID  from [Sites] where SiteCode= [Param] ), 1 from dbo.fun_splitstring(@site_Ids)
 
 
select @UserID,SiteID,1 from (
select [Param] from  dbo.fun_splitstring(@site_Ids) ) as tb
inner join [Sites] on LTRIM(RTRIM([Param]))=LTRIM(RTRIM(SiteID))


 
	  Select 'New user has been created'

   END
END;
GO
/****** Object:  StoredProcedure [dbo].[sp_VerifiedAllTestResultByCOAID]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE  [dbo].[sp_VerifiedAllTestResultByCOAID]
(
    @COAID INT,
    @UserID  int
)
AS
BEGIN

if( select  count(*) from QCTestResults   WHERE COAID = @COAID  and Result is null) >0

begin

  select  'enter results value'
end

else
   
   begin
        UPDATE QCTestResults
        SET IsPassed = 1,
         VerifiedBy=@UserID
        ,VerifiedAt=GETDATE()
        WHERE COAID = @COAID;


         UPDATE COA
         SET 
         CheckedBy=@UserID
         ,[Status]=9 
        ,CheckedAt=GETDATE()
         WHERE Id = @COAID;


         select 'update successfully'

         end
   
    
END
GO
/****** Object:  StoredProcedure [dbo].[usp_UserPagination]    Script Date: 6/7/2026 11:44:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[usp_UserPagination]
    @page        INT,
    @size        INT,
    @search      NVARCHAR(MAX) = '',
    @orderBy     NVARCHAR(MAX) = 'UserID',
    @orderDir    NVARCHAR(MAX) = 'DESC'
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @skip INT = (@size * @page) - @size;
    DECLARE @sql NVARCHAR(MAX);
    DECLARE @whereClause NVARCHAR(MAX) = N'';

    -- SAFE ORDER DIR
    IF UPPER(@orderDir) NOT IN ('ASC','DESC')
        SET @orderDir = 'DESC';

    -- SAFE SEARCH FILTER
    IF LTRIM(RTRIM(@search)) <> ''
    BEGIN
        SET @whereClause = N'
        WHERE 
            LOWER(U.FullName) LIKE ''%'' + LOWER(@search) + ''%''
         OR LOWER(U.Email) LIKE ''%'' + LOWER(@search) + ''%''
         OR LOWER(D.DepartmentName) LIKE ''%'' + LOWER(@search) + ''%''
        ';
    END

    SET @sql = N'
    WITH PaginatedUsers AS (
        SELECT 
            U.UserID,
           U.FullName as Username,
            U.Email,
            U.IsActive,
            U.CreatedAt,
            U.DepartmentId,
            U.RawPassword,
            R.RoleID,
            R.RoleName,
            D.DepartmentName,
              
            COALESCE(CAST(D.DepartmentId AS NVARCHAR), ''No Department'') AS DeptId,

            (
                SELECT STUFF((
                    SELECT '', '' + S.SiteName
                    FROM Sites S
                    INNER JOIN UserSiteAccess USA ON USA.SiteID = S.SiteID
                    WHERE USA.UserID = U.UserID
                    FOR XML PATH(''''), TYPE
                ).value(''.'', ''NVARCHAR(MAX)''),1,2,'''')
            ) AS SiteNames,

            (
                SELECT STUFF((
                    SELECT '', '' + CAST(S.SiteID AS VARCHAR(10))
                    FROM Sites S
                    INNER JOIN UserSiteAccess USA ON USA.SiteID = S.SiteID
                    WHERE USA.UserID = U.UserID
                    FOR XML PATH(''''), TYPE
                ).value(''.'', ''NVARCHAR(MAX)''),1,2,'''')
            ) AS SiteIDs,

            ROW_NUMBER() OVER (
                ORDER BY U.' + QUOTENAME(@orderBy) + ' ' + @orderDir + '
            ) AS RowNum

        FROM dbo.Users U
       
        INNER JOIN Roles R ON R.RoleID = U.RoleID
        INNER JOIN Departments D ON U.DepartmentId = D.DepartmentId
        ' + @whereClause + '
    )

    SELECT *
    FROM PaginatedUsers
    WHERE RowNum BETWEEN ' + CAST(@skip + 1 AS NVARCHAR(20)) + ' 
                     AND ' + CAST(@skip + @size AS NVARCHAR(20)) + ';

    SELECT 
        (
            SELECT COUNT(*)
            FROM dbo.Users U
          
             INNER JOIN Roles R ON R.RoleID = U.RoleID
            INNER JOIN Departments D ON U.DepartmentId = D.DepartmentId
            ' + @whereClause + '
        ) AS Filtered,

        (SELECT COUNT(*) FROM dbo.Users) AS Total;
    ';

    EXEC sp_executesql @sql, N'@search NVARCHAR(MAX)', @search;
END

--EXEC [usp_UserPagination] @page = 1, @size = 5
--EXEC [usp_UserPagination] @page = 1, @size = 1, @search = 'a'
--EXEC [usp_UserPagination] @page = 1, @size = 5, @search = 'a', @orderBy = 'username', @orderDir = 'ASC'
--EXEC [usp_UserPagination] @page = 1, @size = 5, @search = '', @orderBy = 'username', @orderDir = 'ASC'
GO
USE [master]
GO
ALTER DATABASE [TQMS] SET  READ_WRITE 
GO
